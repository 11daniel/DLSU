/* sample1.c */
#include <stdio.h>

#define SIZE 500

int
main()
{
    int A[SIZE];  // 1D array
    int i;

    /* input array elements */
    for (i = 0; i < SIZE; i++)
        scanf("%d", &A[i]);

    /* output array elements */
    for (i = 0; i < SIZE; i++)
        printf("%d\n", A[i]);

    return 0;
}