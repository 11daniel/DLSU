// const or var <varname> = require('<moduleName>');
const http = require('http'); 
const server = http.createServer((req,res) => {
    if (req.url === '/')
    {
        res.write('<h1>Hello World!</h1>');
        res.end();
    }
    if (req.url === '/users')
    {
        res.write("<h1> Viewing User list! </h1><br>");
        res.write(JSON.stringify([1,2,3]));
        res.end();
    }
    if (req.url === '/users/playlists')
    {
        res.write("Viewing user playlists");
        res.end();
    }

    if (req.url === "/records")
    {
        res.write("Viewing records");
        res.end();
    }
});

server.listen(5000);

console.log("Listening on port 5000...");