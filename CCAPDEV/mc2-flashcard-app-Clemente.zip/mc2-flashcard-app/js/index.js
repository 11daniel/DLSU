// TODO: Write your code below
$(document).ready(function() {
    $('#add-card-btn').click(function() {
        // Validate form input
        const frontText = $('#front-card-field').val().trim();
        const backText = $('#back-card-field').val().trim();
        const cardColor = $('#card-color').val();
        if (!frontText || !backText) {
            $('#form-error-msg').show();
            if (!frontText && !backText) {
                $('#form-error-msg').text('Both front and back fields are required!');
            } else if (!frontText) {
                $('#form-error-msg').text('Front field is required!');
            } else if (!backText) {
                $('#form-error-msg').text('Back field is required!');
            }
            return;
        } else {
            $('#form-error-msg').hide();
        }

        // Create flashcard
        const cardHTML = `
            <div class="flashcard" style="background-color: ${cardColor};">
                <div class="flashcard-text">
                    <p class="card-text front">${frontText}</p>
                    <p class="card-text back" hidden>${backText}</p>
                </div>
                <div class="card-bottom-row">
                    <span class="card-date-label">Added on <span class="date-added">${new Date().toUTCString()}</span></span>
                    <span class="card-side-label">Front</span>
                </div>
            </div>
        `;

        // Append new card
        $('#cardlist-div').append(cardHTML);

        // Clear form fields
        $('#front-card-field').val('');
        $('#back-card-field').val('');
        $('#card-color').val('#ffffff');
    });

    // Flip card functionality
    $(document).on('click', '.flashcard', function() {
        $(this).find('.card-text').toggle();
        const sideLabel = $(this).find('.card-side-label');
        if (sideLabel.text() === 'Front') {
            sideLabel.text('Back');
        } else {
            sideLabel.text('Front');
        }
    });
});