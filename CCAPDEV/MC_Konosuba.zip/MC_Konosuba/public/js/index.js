$(document).ready(function () {

    // COMPLETE this code here
    $("#submit").click(function() {
        
        var name = $("#name").val();
        var cost = $("#number").val();
        var er1 = false;
        var er2 = false;

        // check if name is empty
        if (name) {
            er1 = true;
        }
        if (cost) { // check if cost is valid
            er2 = true;
        }

        if (er1 == false && er2 == false) { // apppend the orders
          $("#orders").append("<div>EXPLOSION!</div>");
        }
    });
})

$(document).on("click", ".remove", function(){
    // Might come in handy for delete. :)
});
