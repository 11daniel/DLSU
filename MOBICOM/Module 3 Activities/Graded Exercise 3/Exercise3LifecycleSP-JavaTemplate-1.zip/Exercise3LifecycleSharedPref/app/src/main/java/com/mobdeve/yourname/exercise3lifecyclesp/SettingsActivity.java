package com.mobdeve.yourname.exercise3lifecyclesp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Switch;

public class SettingsActivity extends AppCompatActivity {

    // Views for the switches
    private Switch linearViewSwitch, hideLikeSwitch;

    // Indicators for what Layout should be used or if the like buttons should be hidden
    private int viewSelected = LayoutType.LINEAR_VIEW_TYPE.ordinal(); // int of LayoutType.LINEAR_VIEW_TYPE (default) or LayoutType.GRID_VIEW_TYPE
    private boolean hideLikeSelected = false; // true -> hidden buttons; false -> shown buttons (default)

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // Instantiation of the Switch views
        this.linearViewSwitch = findViewById(R.id.viewSwitch);
        this.hideLikeSwitch = findViewById(R.id.hideLikeSwitch);
    }

    /*
     * Method to map an integer to the appropriate boolean value based on the given LayoutType.
     * */
    private Boolean returnBoolean(int value) {
        if(value == LayoutType.LINEAR_VIEW_TYPE.ordinal())
            return true;
        else
            return false;
    }

    /*
     * Method to map a boolean value (representing whether the linearViewSwitch is checked or not)
     * to appropriate LayoutType in ordinal representation.
     * */
    private int returnInt(Boolean value) {
        if(value == true)
            return LayoutType.LINEAR_VIEW_TYPE.ordinal();
        else
            return LayoutType.GRID_VIEW_TYPE.ordinal();
    }
}