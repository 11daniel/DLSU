package com.mobdeve.yourname.exercise3lifecyclesp;

import android.view.View;
import android.widget.ImageView;

public class GridViewHolder extends CustomViewHolder {
    private ImageView gridPostImageIv;
    private ImageView gridLikeIbtn;

    public GridViewHolder(View itemView) {
        super(itemView);

        this.gridPostImageIv = itemView.findViewById(R.id.gridPostImageIv);
        this.gridLikeIbtn = itemView.findViewById(R.id.gridLikeIbtn);
    }

    @Override
    public void bindData(PostModel post) {
        this.gridPostImageIv.setImageResource(post.getImageId());

        if(post.getLiked()) {
            this.gridLikeIbtn.setImageResource(R.drawable.ic_like_on_foreground);
        } else {
            this.gridLikeIbtn.setImageResource(R.drawable.ic_like_off_foreground);
        }
    }

    @Override
    public void setLikeBtnOnClickListener(View.OnClickListener onClickListener) {
        this.gridLikeIbtn.setOnClickListener(onClickListener);
    }

    @Override
    public void setLikeBtnVisibility(int value) {
        this.gridLikeIbtn.setVisibility(value);
    }
}
