package com.mobdeve.yourname.exercise3lifecyclesp;

import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class LinearViewHolder extends CustomViewHolder {
    private TextView headerUsernameTv, captionUsernameTv, captionTv, datePostedTv, locationTv;
    private LinearLayout captionHll;
    private ImageView accountImageIv, postImageIv;
    private ImageButton likeIbtn;

    public LinearViewHolder(View itemView) {
        super(itemView);

        this.headerUsernameTv = itemView.findViewById(R.id.headerUsernameTv);
        this.captionUsernameTv = itemView.findViewById(R.id.captionUsernameTv);
        this.captionTv = itemView.findViewById(R.id.captionTv);
        this.datePostedTv = itemView.findViewById(R.id.dateTv);
        this.locationTv = itemView.findViewById(R.id.locationTv);

        this.captionHll = itemView.findViewById(R.id.captionHll);

        this.accountImageIv = itemView.findViewById(R.id.accountImageIv);
        this.postImageIv = itemView.findViewById(R.id.postImageIv);

        this.likeIbtn = itemView.findViewById(R.id.gridLikeIbtn);
    }

    @Override
    public void bindData(PostModel post) {
        this.headerUsernameTv.setText(post.getUsername());
        this.captionUsernameTv.setText(post.getUsername());
        this.datePostedTv.setText(post.getDatePosted());
        this.accountImageIv.setImageResource(post.getUserImageId());
        this.postImageIv.setImageResource(post.getImageId());

        if(post.getCaption() == null) {
            captionHll.setVisibility(LinearLayout.GONE);
        } else {
            this.captionTv.setText(post.getCaption());
        }

        if(post.getLocation() == null) {
            locationTv.setVisibility(View.GONE);
        } else {
            this.locationTv.setText(post.getLocation() );
        }

        if(post.getLiked()) {
            this.likeIbtn.setImageResource(R.drawable.ic_like_on_foreground);
        } else {
            this.likeIbtn.setImageResource(R.drawable.ic_like_off_foreground);
        }
    }

    @Override
    public void setLikeBtnOnClickListener(View.OnClickListener onClickListener) {
        this.likeIbtn.setOnClickListener(onClickListener);
    }

    @Override
    public void setLikeBtnVisibility(int value) {
        this.likeIbtn.setVisibility(value);
    }
}
