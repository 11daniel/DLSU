package com.mobdeve.yourname.exercise3lifecyclesp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;


public class MyAdapter extends RecyclerView.Adapter<CustomViewHolder> {
    private ArrayList<PostModel> data;

    /* Variables to keep track of the current apps settings. Each variable has a setter and these
     * values must be set or else the Adapter will not be able to... adapt... appropriately.
     * */
    private Boolean hideLikeBtn;
    private int viewType;

    public MyAdapter(ArrayList<PostModel> data) {
        this.data = data;
    }

    public void setViewType(int viewType) {
        this.viewType = viewType;
    }

    public void setHideLikeBtn(Boolean value) {
        this.hideLikeBtn = value;
    };

    /*
     * We override this method of the Adapter to return the appropriate layout ID based on the
     * viewType currently set. See onCreateViewHolder for intuition.
     * */
    @Override
    public int getItemViewType(int position) {
        if(this.viewType == LayoutType.LINEAR_VIEW_TYPE.ordinal())
            return R.layout.item_linear_layout;
        else
            return R.layout.item_grid_format;
    }

    /*
     * The viewType in the method's parameter corresponds with the value returned by
     * getItemViewType; hence, why we modified getItemViewType to return the layout ID. The layout
     * ID is returned so it's easier to plug into the layoutInflater.inflate method call. Otherwise,
     * we'd need a switch or if+else statement to determine which layout to use. Layout IDs (or
     * view IDs in general) are unique and won't overlap; hence, why this is alright to do.
     * */
    @Override
    public CustomViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // Inflate the appropriate layout based on the viewType returned and generate the itemView.
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View itemView = layoutInflater.inflate(viewType, parent, false);

        // Determine which subclass of CustomViewHolder to generate based on the viewType
        CustomViewHolder holder;
        if(viewType == R.layout.item_linear_layout)
            holder = new LinearViewHolder(itemView);
        else
            holder = new GridViewHolder(itemView);

        // Set the like button logic here
        holder.setLikeBtnOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(data.get(holder.getAdapterPosition()).getLiked()) {
                    ((ImageButton) view).setImageResource(R.drawable.ic_like_off_foreground);
                    data.get(holder.getAdapterPosition()).setLiked(false);
                } else {
                    ((ImageButton) view).setImageResource(R.drawable.ic_like_on_foreground);
                    data.get(holder.getAdapterPosition()).setLiked(true);
                }
            }
        });

        // Hide or display the like button (regardless of viewType) based on hideLikeBtn
        if(hideLikeBtn)
            holder.setLikeBtnVisibility(View.GONE);
        else
            holder.setLikeBtnVisibility(View.VISIBLE);

        return holder;
    }

    /*
     * Utilize the bindData method all CustomViewHolders should have and pass actual binding logic
     * to the ViewHolders depending on what they are.
     * */
    @Override
    public void onBindViewHolder(CustomViewHolder holder, int position) {
        holder.bindData(data.get(position));
    }

    /*
     * You thought it was a comment, but no!! It's me, DIO!
     * */
    @Override
    public int getItemCount() {
        return data.size();
    }
}
