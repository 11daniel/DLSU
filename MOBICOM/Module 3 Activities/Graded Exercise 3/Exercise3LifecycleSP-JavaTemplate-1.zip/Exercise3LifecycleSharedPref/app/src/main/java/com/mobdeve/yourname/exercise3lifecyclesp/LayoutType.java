package com.mobdeve.yourname.exercise3lifecyclesp;

public enum LayoutType {
    LINEAR_VIEW_TYPE,
    GRID_VIEW_TYPE
}
