package com.mobdeve.yourname.exercise3lifecyclesp;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<PostModel> data;

    // RecyclerView components
    private RecyclerView recyclerView;
    private MyAdapter myAdapter;

    // Indicators for what Layout should be used or if the like buttons should be hidden
    private int recyclerViewDefaultView = LayoutType.LINEAR_VIEW_TYPE.ordinal();    // int of LayoutType.LINEAR_VIEW_TYPE (default) or LayoutType.GRID_VIEW_TYPE
    private boolean hideLikeButtons = false;    // true = hide buttons; false = shown buttons (default)

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize the data, recyclerView and adapter
        this.data = new DataHelper().initializeData();
        this.recyclerView = findViewById(R.id.recyclerView);
        this.myAdapter = new MyAdapter(data);

        // Set the layout manager according to the default view
        this.recyclerView.setLayoutManager(getLayoutManager(recyclerViewDefaultView));

        // Initialize the view type and hide like button settings
        this.myAdapter.setViewType(recyclerViewDefaultView);
        this.myAdapter.setHideLikeBtn(this.hideLikeButtons);

        // Sets the adapter of the recycler view
        this.recyclerView.setAdapter(this.myAdapter);
    }

    /*
     * Just a method to return a specific LayoutManager based on the ViewType provided.
     * */
    private RecyclerView.LayoutManager getLayoutManager(int value) {
        if(value == LayoutType.LINEAR_VIEW_TYPE.ordinal())
            return new LinearLayoutManager(this);
        else
            return new GridLayoutManager(this, 2);
    }

    /*
    * Responsible for inflating the options menu on the upper right corner of the screen.
    * */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    /*
     * A little overkill tbh, but this method is responsible for handling the selection of items
     * in the options menu. There's only one item anyway -- Settings, which leads the user to the
     * Settings activity.
     * */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_settings:
                Intent i = new Intent(MainActivity.this, SettingsActivity.class);
                startActivity(i);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}