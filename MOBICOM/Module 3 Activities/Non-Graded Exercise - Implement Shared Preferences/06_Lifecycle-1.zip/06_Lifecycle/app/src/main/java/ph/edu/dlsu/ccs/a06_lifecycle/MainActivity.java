package ph.edu.dlsu.ccs.a06_lifecycle;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    private EditText
            onCreateField, onStartField, onResumeField,
            onPauseField, onStopField, onDestroyField;
    private int
            createVal, startVal, resumeVal,
            pauseVal, stopVal, destroyVal;

    //(1) onCreate is the function called when the activity is created.
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.d(TAG,"onCreate called");

        this.onCreateField = findViewById(R.id.onCreateField);
        this.onStartField = findViewById(R.id.onStartField);
        this.onResumeField = findViewById(R.id.onResumeField);
        this.onPauseField = findViewById(R.id.onPauseField);
        this.onStopField = findViewById(R.id.onStopField);
        this.onDestroyField = findViewById(R.id.onDestroyField);

        this.createVal = 0;
        this.startVal = 0;
        this.resumeVal = 0;
        this.pauseVal = 0;
        this.stopVal = 0;
        this.destroyVal = 0;

        Button button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                MainActivity.this.startActivity(intent);
            }
        });

        this.createVal++;
        onCreateField.setText(String.valueOf(this.createVal));
    }

    //(2) onStart is the function called when the activity is about to become visible.
    @Override
    protected void onStart(){
        super.onStart();
        Log.d(TAG, "onStart called");

        this.startVal++;
        onStartField.setText(String.valueOf(this.startVal));
    }

    //(3) onResume is the function called when the activity is going to resume
    //    from another activity.
    @Override
    protected void onResume(){
        super.onResume();
        Log.d(TAG, "onResume called");

        this.resumeVal++;
        onResumeField.setText(String.valueOf(this.resumeVal));
    }

    //(4) onPause is the function called when the activity is about to start
    //    another activity.
    @Override
    protected void onPause(){
        super.onPause();
        Log.d(TAG, "onPause called");

        this.pauseVal++;
        onPauseField.setText(String.valueOf(this.pauseVal));
    }

    //(5) onStop is the function called when the activity is no longer visible
    @Override
    protected void onStop(){
        super.onStop();
        Log.d(TAG, "onStop called");

        this.stopVal++;
        onStopField.setText(String.valueOf(this.stopVal));
    }

    //(6) onDestroy is the function called when the activity is destroyed
    @Override
    protected void onDestroy(){
        super.onDestroy();
        Log.d(TAG,"onDestroy called");

        // Yes... for now, this doesn't really do anything.
        this.destroyVal++;
        onDestroyField.setText(String.valueOf(this.destroyVal));
    }

    //(7) To be able to save the information and retain the state when
    //    going on about different views. Use the onSaveInstanceState
    //    function and store the information.
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        Log.d(TAG,"onSaveInstanceState called");
        
        outState.putInt(MyKeys.ON_CREATE_KEY.name(), this.createVal);
        outState.putInt(MyKeys.ON_START_KEY.name(), this.startVal);
        outState.putInt(MyKeys.ON_RESUME_KEY.name(), this.resumeVal);
        outState.putInt(MyKeys.ON_PAUSE_KEY.name(), this.pauseVal);
        outState.putInt(MyKeys.ON_STOP_KEY.name(), this.stopVal);
        outState.putInt(MyKeys.ON_DESTROY_KEY.name(), this.destroyVal);
    }

    //(8) Called when the information is restored. For now, only called
    //    when changing from portrait to landscape
    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        Log.d(TAG,"onRestoreInstanceState called");

        this.createVal = savedInstanceState.getInt(MyKeys.ON_CREATE_KEY.name());
        this.startVal = savedInstanceState.getInt(MyKeys.ON_START_KEY.name());
        this.resumeVal = savedInstanceState.getInt(MyKeys.ON_RESUME_KEY.name());
        this.pauseVal = savedInstanceState.getInt(MyKeys.ON_PAUSE_KEY.name());
        this.stopVal = savedInstanceState.getInt(MyKeys.ON_STOP_KEY.name());
        this.destroyVal = savedInstanceState.getInt(MyKeys.ON_DESTROY_KEY.name());

        this.onCreateField.setText(String.valueOf(this.createVal));
        this.onStartField.setText(String.valueOf(this.startVal));
        this.onResumeField.setText(String.valueOf(this.resumeVal));
        this.onPauseField.setText(String.valueOf(this.pauseVal));
        this.onStopField.setText(String.valueOf(this.stopVal));
        this.onDestroyField.setText(String.valueOf(this.destroyVal));
    }
}
