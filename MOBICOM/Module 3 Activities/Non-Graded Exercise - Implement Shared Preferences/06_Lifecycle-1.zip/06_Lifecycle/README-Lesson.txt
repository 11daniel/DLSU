Lesson notes for project:
1. It is possible to create custom icons using the Image Asset Studio feature found in Android
   studio. More information can be found here:
   - https://developer.android.com/studio/write/image-asset-studio
2. To better understand the optimization on the activities, the lifecycle of an activity
   should be studied.
   - https://developer.android.com/reference/android/app/Activity
   - https://developer.android.com/guide/components/activities/activity-lifecycle
3. More information on the lifecycle is written in the code. Look at the MainActivity class
   and read the comments on it.
4. Android's optimizations cleans data in different ways. This is apparent in the
   previous samples while changing orientation. To be able to retain information, the
   information should be saved. Look at the bottom part of MainActivity to see how this is
   implemented.
   - Notice that the content in private integers are cleaned when onCreate is called after
     the screen orientation was saved.

Self-Practise:
   As a practise, try to modify the project so that the project also tracks the onCreate and
   onDestroy calls. Whenever orientation is changed, even the onCreate is reset. Create a way
   so that it tracks those changes as well. Hint: SharedPreferences