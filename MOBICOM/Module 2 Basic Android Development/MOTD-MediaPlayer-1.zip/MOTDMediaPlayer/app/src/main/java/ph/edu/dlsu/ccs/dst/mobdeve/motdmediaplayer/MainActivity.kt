package ph.edu.dlsu.ccs.dst.mobdeve.motdmediaplayer

import android.media.MediaPlayer
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.ComponentActivity

class MainActivity : ComponentActivity() {
    private lateinit var txt_mediaplayer_state: TextView
    private lateinit var btn_mediaplayer_play: Button
    private lateinit var btn_mediaplayer_pause: Button
    private lateinit var btn_mediaplayer_stop: Button
    private var myAudioPlayer: MediaPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_media_player_sample)
        initializeUI()
        initializeMediaPlayer()
    }

    fun initializeUI() {
        txt_mediaplayer_state = findViewById(R.id.tvw_mediaplayer_state)
        btn_mediaplayer_play = findViewById(R.id.btn_mediaplayer_play)
        btn_mediaplayer_pause = findViewById(R.id.btn_mediaplayer_pause)
        btn_mediaplayer_stop = findViewById(R.id.btn_mediaplayer_stop)
    }

    fun initializeMediaPlayer() {
        btn_mediaplayer_play.setOnClickListener {
            playSound()
            txt_mediaplayer_state.text = "Last button pressed - Play"
        }
        btn_mediaplayer_pause.setOnClickListener {
            pauseSound()
            txt_mediaplayer_state.text = "Last button pressed - " + btn_mediaplayer_pause.text
        }
        btn_mediaplayer_stop.setOnClickListener {
            stopSound()
            txt_mediaplayer_state.text = "Last button pressed - " + getString(R.string.button_stop)
        }
    }

    private fun playSound() {
        if (myAudioPlayer == null) {
            myAudioPlayer = MediaPlayer.create(this, R.raw.click_sound)
            myAudioPlayer!!.isLooping = true
            myAudioPlayer!!.start()
        } else myAudioPlayer!!.start()
    }

    private fun pauseSound() {
        if (myAudioPlayer?.isPlaying == true) myAudioPlayer?.pause()
    }

    private fun stopSound() {
        if (myAudioPlayer != null) {
            myAudioPlayer!!.stop()
            myAudioPlayer!!.release()
            myAudioPlayer = null
        }
    }

    override fun onStop() {
        super.onStop()
        if (myAudioPlayer != null) {
            myAudioPlayer!!.release()
            myAudioPlayer = null
        }
    }
}
