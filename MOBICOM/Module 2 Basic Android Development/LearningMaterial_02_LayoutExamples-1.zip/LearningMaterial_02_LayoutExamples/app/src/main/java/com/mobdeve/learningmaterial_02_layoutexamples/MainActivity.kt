package com.mobdeve.learningmaterial_02_layoutexamples

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        /* We haven't discussed Activities yet, but that's alright. If you want a screen to be
           shown for the meantime, change R.layout.<layout_name> to the layout you want shown.
         */
        setContentView(R.layout.activity_main)

        // Don't forget to check out the drawable, layout, and values folders under res
    }
}