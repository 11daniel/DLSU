package com.mobdeve.dynamicviewcreation_template

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    // Complete the list of View variables here
    private lateinit var firstNameEtv: EditText
    private lateinit var lastNameEtv: EditText
    private lateinit var addBtn: Button
    private lateinit var nameListLl: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize your View variables here using findViewById(R.id.<name of view in XML)
        this.firstNameEtv = findViewById(R.id.firstNameEtv)
        this.lastNameEtv = findViewById(R.id.lastNameEtv)
        this.addBtn = findViewById(R.id.addBtn)
        this.nameListLl = findViewById(R.id.nameListLl)

        // Alternatively, you can use View Binding -- see the slides to enable View Binding

        // To add logic to the addBtn, add an onClickListener
        // Explore the auto-fill feature of Android Studio to find the appropriate method
        // After which:
        //  (1) Create a TextView object
        //  (2) Set the Text attribute of the object to the <Last>, <First> format
        //  (3) Add the newly created view to the LinearLayout
        this.addBtn.setOnClickListener {
            val nameTextView = TextView(this)
            nameTextView.layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT)
            val fullName = lastNameEtv.text.toString() + ", " + firstNameEtv.text.toString()
            nameTextView.setText(fullName)
            nameListLl.addView(nameTextView)
        }
    }
}