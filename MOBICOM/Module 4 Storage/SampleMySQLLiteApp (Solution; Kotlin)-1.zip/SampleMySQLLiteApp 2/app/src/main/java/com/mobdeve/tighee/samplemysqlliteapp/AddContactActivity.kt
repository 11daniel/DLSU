package com.mobdeve.tighee.samplemysqlliteapp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.mobdeve.tighee.samplemysqlliteapp.databinding.ActivityAddContactBinding
import com.squareup.picasso.Picasso
import java.util.concurrent.Executors

class AddContactActivity : AppCompatActivity() {
    private val executorService = Executors.newSingleThreadExecutor()
    private lateinit var viewBinding : ActivityAddContactBinding
    private lateinit var myDbHelper: MyDbHelper
    private var imageUri: Uri? = null

    private val myActivityResultLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()) { result: ActivityResult ->
        if (result.resultCode == RESULT_OK) {
            try {
                if (result.data != null) {
                    imageUri = result.data!!.data
                    Picasso.get().load(imageUri).into(viewBinding.tempImageIv)
                }
            } catch (exception: Exception) {
                Log.d("TAG", "" + exception.localizedMessage)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        this.viewBinding = ActivityAddContactBinding.inflate(layoutInflater)
        setContentView(this.viewBinding.root)

        this.viewBinding.selectBtn.setOnClickListener(View.OnClickListener {
            val i = Intent()
            i.type = "image/*"
            i.action = Intent.ACTION_OPEN_DOCUMENT
            myActivityResultLauncher.launch(Intent.createChooser(i, "Select Picture"))
        })

        this.viewBinding.addBtn.setOnClickListener(View.OnClickListener { view ->
            if (areFieldsComplete()) {
                executorService.execute {
                    myDbHelper = MyDbHelper.getInstance(this@AddContactActivity)!!
                    myDbHelper.insertContact(
                        Contact(
                            this.viewBinding.lastNameEtv.text.toString(),
                            this.viewBinding.firstNameEtv.text.toString(),
                            this.viewBinding.numberEtv.text.toString(),
                            imageUri.toString()
                        )
                    )
                }

                val i = Intent()
                i.putExtra(IntentKeys.FIRST_NAME_KEY.name, this.viewBinding.firstNameEtv.text.toString())
                i.putExtra(IntentKeys.LAST_NAME_KEY.name, this.viewBinding.lastNameEtv.text.toString())
                i.putExtra(IntentKeys.NUMBER_KEY.name, this.viewBinding.numberEtv.text.toString())
                i.putExtra(IntentKeys.IMAGE_URI_KEY.name, imageUri.toString())
                setResult(RESULT_OK, i)

                finish()
            } else {
                Toast.makeText(view.context, "Please fill up all fields", Toast.LENGTH_LONG).show()
            }
        })
    }

    private fun areFieldsComplete(): Boolean {
        return this.viewBinding.firstNameEtv.text.isNotEmpty() && this.viewBinding.lastNameEtv.text.isNotEmpty() && this.viewBinding.numberEtv.text.isNotEmpty() && (imageUri != null)
    }
}