package com.mobdeve.tighee.samplemysqlliteapp

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.mobdeve.tighee.samplemysqlliteapp.databinding.ItemLayoutBinding

class MyAdapter(private val contacts: ArrayList<Contact>) : RecyclerView.Adapter<MyViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemViewBinding: ItemLayoutBinding = ItemLayoutBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false)
        return MyViewHolder(itemViewBinding)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.bindData(contacts[position])
    }

    override fun getItemCount(): Int {
        return contacts.size
    }
}