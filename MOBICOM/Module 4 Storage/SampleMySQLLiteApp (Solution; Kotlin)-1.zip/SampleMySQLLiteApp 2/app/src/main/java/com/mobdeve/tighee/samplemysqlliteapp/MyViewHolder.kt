package com.mobdeve.tighee.samplemysqlliteapp

import android.net.Uri
import android.util.Log
import androidx.recyclerview.widget.RecyclerView
import com.mobdeve.tighee.samplemysqlliteapp.databinding.ItemLayoutBinding
import com.squareup.picasso.Picasso

class MyViewHolder(private val viewBinding: ItemLayoutBinding) : RecyclerView.ViewHolder(viewBinding.root) {
    fun bindData(c: Contact) {
        viewBinding.nameTv.text = c.lastName + ", " + c.firstName
        viewBinding.numberTv.text = c.number

        Log.d("TAG", "bindData: $c")

        Picasso.get()
            .load(Uri.parse(c.imageUri))
            .into(viewBinding.imageIv)
    }
}