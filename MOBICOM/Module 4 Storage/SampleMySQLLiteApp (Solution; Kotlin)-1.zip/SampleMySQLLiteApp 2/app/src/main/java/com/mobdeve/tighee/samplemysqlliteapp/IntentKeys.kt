package com.mobdeve.tighee.samplemysqlliteapp

enum class IntentKeys {
    LAST_NAME_KEY, FIRST_NAME_KEY, NUMBER_KEY, IMAGE_URI_KEY
}