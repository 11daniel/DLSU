package com.mobdeve.tighee.mychatroomapp;

public enum IntentKeys {
    USERNAME
}
