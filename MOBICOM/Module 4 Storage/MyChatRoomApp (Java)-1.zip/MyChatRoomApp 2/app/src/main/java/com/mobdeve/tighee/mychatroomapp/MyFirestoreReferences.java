package com.mobdeve.tighee.mychatroomapp;

public class MyFirestoreReferences {
    public final static String
            USERS_COLLECTION = "Users",
            MESSAGE_COLLECTION = "Message",

            USERNAME_FIELD = "username",
            MESSAGE_FIELD = "message",
            TIMESTAMP_FIELD = "timestamp";
}
