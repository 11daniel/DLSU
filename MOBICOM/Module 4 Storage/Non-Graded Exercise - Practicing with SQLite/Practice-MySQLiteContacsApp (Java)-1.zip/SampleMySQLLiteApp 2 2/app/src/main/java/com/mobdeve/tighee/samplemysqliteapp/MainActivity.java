package com.mobdeve.tighee.samplemysqliteapp;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private ArrayList<Contact> contacts;

    private RecyclerView recyclerView;
    private MyAdapter myAdapter;

    private FloatingActionButton addContactBtn;

    private ActivityResultLauncher<Intent> myActivityResultLauncher = registerForActivityResult(
        new ActivityResultContracts.StartActivityForResult(),
        new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult result) {
                if (result.getData() != null){
                    // Notice that we're checking our own defined result codes for Add and Edit.
                    if (result.getResultCode() == ResultCodes.ADD_RESULT.ordinal()){ // ADD
                        contacts.add(0, new Contact(
                                result.getData().getStringExtra(IntentKeys.LAST_NAME_KEY.name()),
                                result.getData().getStringExtra(IntentKeys.FIRST_NAME_KEY.name()),
                                result.getData().getStringExtra(IntentKeys.NUMBER_KEY.name()),
                                result.getData().getStringExtra(IntentKeys.IMAGE_URI_KEY.name()))
                        );

                        myAdapter.notifyDataSetChanged();
                    } else if (result.getResultCode() == ResultCodes.EDIT_RESULT.ordinal()) { // EDIT
                        /* TODO: Logic for handling the edit return. Update the RecyclerView.
                         * */



                    }
                }
            }
        });

    private MyDbHelper myDbHelper;
    private ExecutorService executorService = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // this.contacts = new ArrayList<>();
        // We no longer initialized our ArrayList from scratch as we'd want to initialize it with
        // whatever is in the DB -- empty or not.

        // Logic to handle the initialization of our ArrayList
        executorService.execute(new Runnable() {
            @Override
            public void run() {
                myDbHelper = MyDbHelper.getInstance(MainActivity.this);
                contacts = myDbHelper.getAllContactsDefault();
                printAllContacts(); // Prints to the log

                recyclerView = findViewById(R.id.recyclerView);
                recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));
                // Notice we're passing in the myActivityResultLauncher to the Adapter
                myAdapter = new MyAdapter(contacts, myActivityResultLauncher);
                recyclerView.setAdapter(myAdapter);
            }
        });

        this.addContactBtn = findViewById(R.id.addContactBtn);
        this.addContactBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, AddContactActivity.class);
                myActivityResultLauncher.launch(i);
            }
        });
    }

    private void printAllContacts() {
        for(Contact c : contacts) {
            Log.d("MainActivity", "printAllContacts: " + c.toString());
        }
    }
}