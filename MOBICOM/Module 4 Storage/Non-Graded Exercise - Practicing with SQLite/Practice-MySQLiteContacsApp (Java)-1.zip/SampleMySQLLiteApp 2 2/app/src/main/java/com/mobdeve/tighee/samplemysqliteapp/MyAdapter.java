package com.mobdeve.tighee.samplemysqliteapp;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.activity.result.ActivityResultLauncher;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyViewHolder> {
    private ArrayList<Contact> contacts;
    private ActivityResultLauncher<Intent> myActivityResultLauncher;

    public MyAdapter(ArrayList<Contact> contacts, ActivityResultLauncher<Intent> myActivityResultLauncher) {
        this.contacts = contacts;
        this.myActivityResultLauncher = myActivityResultLauncher;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_layout, parent, false);
        MyViewHolder myViewHolder = new MyViewHolder(v);

        /* Edit Logic
         *      To implement an edit, we're going to extend AddContactActivity to accommodate
         *      for editing as well. First, we'll send an intent to the activity with the info
         *      from the contacts ArrayList. In the AddContactActivity, we'll need to know an
         *      edit operation was performed; hence, we'll use the CONTACT_ID_KEY as a reference.
         *      When we retrieve it, we should have a value because the contact-to-edit should
         *      already be in the DB. If no edit was passed, we're assuming its an add. We'll
         *      also need to modify the DB operation in AddContactActivity so that it doesn't
         *      just perform an ADD.
         * */
        myViewHolder.setEditBtnOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(view.getContext(), AddContactActivity.class);
                i.putExtra(IntentKeys.FIRST_NAME_KEY.name(), contacts.get(myViewHolder.getAdapterPosition()).getFirstName());
                i.putExtra(IntentKeys.LAST_NAME_KEY.name(), contacts.get(myViewHolder.getAdapterPosition()).getLastName());
                i.putExtra(IntentKeys.NUMBER_KEY.name(), contacts.get(myViewHolder.getAdapterPosition()).getNumber());
                i.putExtra(IntentKeys.IMAGE_URI_KEY.name(), contacts.get(myViewHolder.getAdapterPosition()).getImageUri());
                i.putExtra(IntentKeys.CONTACT_ID_KEY.name(), contacts.get(myViewHolder.getAdapterPosition()).getId());
                myActivityResultLauncher.launch(i);
            }
        });

        /* Delete Logic
         * TODO: Supply the deletion logic in the onClick method
         *       If you'd rather set the listener from the MainActivity, you can modify the
         *       constructor to accommodate the passing of an OnClickListener. Regardless, you have
         *       a copy of the Contacts data in the Adapter, so you can modify the data here.
         * */
        myViewHolder.setDeleteBtnOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {




            }
        });

        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        holder.bindData(this.contacts.get(position));
    }

    @Override
    public int getItemCount() {
        return this.contacts.size();
    }
}
