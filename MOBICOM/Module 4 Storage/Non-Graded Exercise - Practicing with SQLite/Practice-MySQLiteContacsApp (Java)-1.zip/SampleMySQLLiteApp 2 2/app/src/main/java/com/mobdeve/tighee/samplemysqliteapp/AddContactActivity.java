package com.mobdeve.tighee.samplemysqliteapp;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AddContactActivity extends AppCompatActivity {

    // These variables carry over from the previous implementation
    private EditText firstNameEtv, lastNameEtv, numberEtv;
    private ImageView tempImageIv;
    private Button selectBtn, addBtn;
    // We added a reference to the title of the activity so we can change it from "Add" to "Edit"
    // depending on what the user wants to do.
    private TextView titleTv;

    private Uri imageUri = null;

    private ActivityResultLauncher<Intent> myActivityResultLauncher = registerForActivityResult(
        new ActivityResultContracts.StartActivityForResult(),
        new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult result) {
                if (result.getResultCode() == Activity.RESULT_OK){
                    try {
                        if(result.getData() != null) {
                            imageUri = result.getData().getData();
                            Picasso.get().load(imageUri).into(tempImageIv);
                        }
                    } catch(Exception exception){
                        Log.d("TAG",""+exception.getLocalizedMessage());
                    }
                }
            }
        });

    private MyDbHelper myDbHelper;
    private ExecutorService executorService = Executors.newSingleThreadExecutor();

    // We added a contactId variable so we can keep track of where we should edit in the DB.
    // We assign it -1 as the default value.
    private long contactId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_contact);

        // Initialize our View references
        this.firstNameEtv = findViewById(R.id.firstNameEtv);
        this.lastNameEtv = findViewById(R.id.lastNameEtv);
        this.numberEtv = findViewById(R.id.numberEtv);
        this.tempImageIv = findViewById(R.id.tempImageIv);
        this.selectBtn = findViewById(R.id.selectBtn);
        this.addBtn = findViewById(R.id.addBtn);
        this.titleTv = findViewById(R.id.titleTv);

        // Check if an intent is there (i.e. if its coming for an EDIT operation)
        Intent i = getIntent();
        this.contactId = i.getLongExtra(IntentKeys.CONTACT_ID_KEY.name(), -1);

        // If the contactId is default, it means there's no intent. If there is a value other than
        // -1, then we need to edit.
        if(this.contactId != -1) {
            this.firstNameEtv.setText(i.getStringExtra(IntentKeys.FIRST_NAME_KEY.name()));
            this.lastNameEtv.setText(i.getStringExtra(IntentKeys.LAST_NAME_KEY.name()));
            this.numberEtv.setText(i.getStringExtra(IntentKeys.NUMBER_KEY.name()));
            this.imageUri = Uri.parse(i.getStringExtra(IntentKeys.IMAGE_URI_KEY.name()));

            Picasso.get().load(this.imageUri).into(tempImageIv);

            // Para alam ni user na edit ang gagawin, hindi add
            this.addBtn.setText("EDIT CONTACT");
            this.titleTv.setText("Edit Contact");
        }

        this.selectBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent();
                i.setType("image/*");
                i.setAction(Intent.ACTION_OPEN_DOCUMENT);
                myActivityResultLauncher.launch(Intent.createChooser(i, "Select Picture"));
            }
        });

        // Note that while this is logic for the "add" button, it also should contain logic that
        // handles when an edit operation is performed.
        this.addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(areFieldsComplete()) {
                    /*
                     * TODO: Handle the logic for knowing whether its an add or edit operation.
                     *       HINT: Utilize whether or not the contactId is the default value.
                     * */
                    executorService.execute(new Runnable() {
                        @Override
                        public void run() {
                            // This is logic for adding a Contact
                            myDbHelper = MyDbHelper.getInstance(AddContactActivity.this);
                            myDbHelper.insertContact(new Contact(
                                    lastNameEtv.getText().toString(),
                                    firstNameEtv.getText().toString(),
                                    numberEtv.getText().toString(),
                                    imageUri.toString()
                            ));

                            /*
                             *  TODO: When an add returns to the MainActivity, we don't actually
                             *        include the ID that was generated by the DB. To do so, modify
                             *        the insertContact() method in the DbHelper to return the
                             *        generated ID. Modifying the method means modifying the logic
                             *        above as well.
                             *        HINT: db.insert() returns the ID of the row if successful.
                             * */



                        }
                    });

                    // Handles the logic to return the Contact information back
                    Intent i = new Intent();
                    i.putExtra(IntentKeys.FIRST_NAME_KEY.name(), firstNameEtv.getText().toString());
                    i.putExtra(IntentKeys.LAST_NAME_KEY.name(), lastNameEtv.getText().toString());
                    i.putExtra(IntentKeys.NUMBER_KEY.name(), numberEtv.getText().toString());
                    i.putExtra(IntentKeys.IMAGE_URI_KEY.name(), imageUri.toString());
                    // Notice that we changed the result code that was previously RESULT_OK. We
                    // replaced it with our own code -- ResultCodes.ADD_RESULT
                    setResult(ResultCodes.ADD_RESULT.ordinal(), i);

                    /*
                     * TODO: Make sure to modify the setting of the result to an ADD_RESULT or
                     *       EDIT_RESULT (see our ResultCodes class). Currently, the code above only
                     *       performs the add. Modify it so that we can send either add or edit
                     *       flags back.
                     * */



                    finish();
                } else {
                    Toast.makeText(view.getContext(), "Please fill up all fields", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private boolean areFieldsComplete() {
        return !(firstNameEtv.getText().toString().equals("") || lastNameEtv.getText().toString().equals("") || numberEtv.getText().toString().equals("") || imageUri == null);
    }
}