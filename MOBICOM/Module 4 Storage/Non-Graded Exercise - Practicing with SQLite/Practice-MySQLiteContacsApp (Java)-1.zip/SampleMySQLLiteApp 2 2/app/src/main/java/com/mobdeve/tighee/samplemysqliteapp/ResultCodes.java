package com.mobdeve.tighee.samplemysqliteapp;

public enum ResultCodes {
    ADD_RESULT,
    EDIT_RESULT,
}

