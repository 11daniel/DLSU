package com.mobdeve.tighee.samplemysqliteapp

enum class ResultCodes {
    ADD_RESULT, EDIT_RESULT
}