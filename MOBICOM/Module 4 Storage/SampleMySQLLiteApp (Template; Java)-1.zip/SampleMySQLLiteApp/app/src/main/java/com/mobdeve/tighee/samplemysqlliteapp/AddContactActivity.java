package com.mobdeve.tighee.samplemysqlliteapp;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

public class AddContactActivity extends AppCompatActivity {

    private EditText firstNameEtv, lastNameEtv, numberEtv;
    private ImageView tempImageIv;
    private Button selectBtn, addBtn;

    private String imageUri = null;

    private ActivityResultLauncher<Intent> myActivityResultLauncher = registerForActivityResult(
        new ActivityResultContracts.StartActivityForResult(),
        new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult result) {
                if (result.getResultCode() == Activity.RESULT_OK){
                    try {
                        if(result.getData() != null) {
                            imageUri = result.getData().getData().toString();
                            Picasso.get().load(imageUri).into(tempImageIv);
                        }
                    } catch(Exception exception){
                        Log.d("TAG",""+exception.getLocalizedMessage());
                    }
                }
            }
        });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_contact);

        this.firstNameEtv = findViewById(R.id.firstNameEtv);
        this.lastNameEtv = findViewById(R.id.lastNameEtv);
        this.numberEtv = findViewById(R.id.numberEtv);
        this.tempImageIv = findViewById(R.id.tempImageIv);
        this.selectBtn = findViewById(R.id.selectBtn);
        this.addBtn = findViewById(R.id.addBtn);

        this.selectBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                myActivityResultLauncher.launch(i);
            }
        });

        this.addBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                if(areFieldsComplete()) {
                    Intent i = new Intent();
                    i.putExtra(IntentKeys.FIRST_NAME_KEY.name(), firstNameEtv.getText().toString());
                    i.putExtra(IntentKeys.LAST_NAME_KEY.name(), lastNameEtv.getText().toString());
                    i.putExtra(IntentKeys.NUMBER_KEY.name(), numberEtv.getText().toString());
                    i.putExtra(IntentKeys.IMAGE_URI_KEY.name(), imageUri);
                    setResult(Activity.RESULT_OK, i);
                    finish();
                } else {
                    Toast.makeText(view.getContext(), "Please fill up all fields", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private boolean areFieldsComplete() {
        return !(firstNameEtv.getText().toString().equals("") || lastNameEtv.getText().toString().equals("") || numberEtv.getText().toString().equals("") || imageUri == null);
    }
}