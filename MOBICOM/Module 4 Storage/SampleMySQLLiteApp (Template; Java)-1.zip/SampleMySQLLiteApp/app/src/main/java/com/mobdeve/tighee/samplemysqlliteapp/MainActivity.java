package com.mobdeve.tighee.samplemysqlliteapp;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<Contact> contacts;

    private RecyclerView recyclerView;
    private MyAdapter myAdapter;

    private FloatingActionButton addContactBtn;

    private ActivityResultLauncher<Intent> myActivityResultLauncher = registerForActivityResult(
        new ActivityResultContracts.StartActivityForResult(),
        new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult result) {
                if (result.getResultCode() == Activity.RESULT_OK){
                    if (result.getData() != null){
                        contacts.add(0, new Contact(
                            result.getData().getStringExtra(IntentKeys.LAST_NAME_KEY.name()),
                            result.getData().getStringExtra(IntentKeys.FIRST_NAME_KEY.name()),
                            result.getData().getStringExtra(IntentKeys.NUMBER_KEY.name()),
                            result.getData().getStringExtra(IntentKeys.IMAGE_URI_KEY.name()))
                        );
                        myAdapter.notifyItemChanged(0);
                    }
                }
            }
        });
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.contacts = new ArrayList<>();

        this.recyclerView = findViewById(R.id.recyclerView);
        this.recyclerView.setLayoutManager(new LinearLayoutManager(this));
        this.myAdapter = new MyAdapter(contacts);
        this.recyclerView.setAdapter(this.myAdapter);

        this.addContactBtn = findViewById(R.id.addContactBtn);
        this.addContactBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, AddContactActivity.class);
                myActivityResultLauncher.launch(i);
            }
        });
    }
}