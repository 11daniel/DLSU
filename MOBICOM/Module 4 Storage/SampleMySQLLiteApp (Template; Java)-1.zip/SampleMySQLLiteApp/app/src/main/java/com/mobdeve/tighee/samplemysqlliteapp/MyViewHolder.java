package com.mobdeve.tighee.samplemysqlliteapp;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;


import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

public class MyViewHolder extends RecyclerView.ViewHolder {
    private TextView nameTv, numberTv;
    private ImageView imageIv;

    public MyViewHolder(View itemView) {
        super(itemView);

        this.nameTv = itemView.findViewById(R.id.nameTv);
        this.numberTv = itemView.findViewById(R.id.numberTv);
        this.imageIv = itemView.findViewById(R.id.imageIv);
    }

    public void bindData(Contact c) {
        this.nameTv.setText(c.getLastName() + ", " + c.getFirstName());
        this.numberTv.setText(c.getNumber());
        Picasso.get()
            .load(c.getImageUri())
            .into(this.imageIv);
    }
}
