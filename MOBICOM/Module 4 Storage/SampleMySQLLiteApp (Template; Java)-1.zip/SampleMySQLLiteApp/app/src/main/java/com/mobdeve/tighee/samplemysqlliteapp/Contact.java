package com.mobdeve.tighee.samplemysqlliteapp;

public class Contact {
    private int id;
    private String lastName, firstName, number, imageUri;

    public Contact(String lastName, String firstName, String number, String imageUri) {
        this.lastName = lastName;
        this.firstName = firstName;
        this.number = number;
        this.imageUri = imageUri;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLastName() {
        return lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getNumber() {
        return number;
    }

    public String getImageUri() {
        return imageUri;
    }
}
