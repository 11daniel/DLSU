package com.mobdeve.tighee.fotostreamapp;

public enum IntentKeys {
    USER_ID_KEY,
    POST_ID_KEY,
    USERNAME_KEY
}
