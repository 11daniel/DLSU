package com.mobdeve.tighee.mychatroomapp

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.CollectionReference
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.mobdeve.tighee.mychatroomapp.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {
    companion object {
        private const val TAG = "LoginActivity"
    }

    private lateinit var viewBinding : ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialization of View Binding
        this.viewBinding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(this.viewBinding.root)

        // On click, check if the input username is in the DB. If it isn't, then prompt the user
        // that the username will be recorded into the DB. If it is in the DB, then proceed to the
        // ChatRoomActivity with the username in the sending intent.
        this.viewBinding.loginBtn.setOnClickListener(View.OnClickListener {
            val username = this.viewBinding.usernameEtv.text.toString()

            // Get the DB from Firebase
            val db = Firebase.firestore
            // Get the User collection reference
            val usersRef = db.collection(MyFirestoreReferences.USERS_COLLECTION)

            // Query the User collection reference to find entries with the given username
            val query = usersRef.whereEqualTo(
                MyFirestoreReferences.USERNAME_FIELD,
                username
            )

            // Perform the query and add an OnCompleteListener to know when the query has finished.
            // Logic in the OnCompleteListener is performed on completion of the query.
            query.get().addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    // If there are no results, then there is no sign of the username in the DB.
                    if (task.result.isEmpty) {
                        showNewUserDialog(usersRef, username)
                    } else { // Otherwise, move ot the chatroom with the usernaem specified
                        moveToChatRoomActivity(username)
                    }
                } else {
                    Log.d(TAG, "Error getting documents: ", task.exception)
                }
            }
        })
    }

    /*
     * This function was made to reduce the amount of code in OnCreate. Basically, it generates a
     * Dialog informing the user that the username has not been found and that the app would like
     * to create an account for them. Two options are presented to the user: (Yes) to proceed with
     * "creating" the account and pushing the username into the DB and (No) to simply cancel the
     * operation.
     * */
    private fun showNewUserDialog(usersRef: CollectionReference, username: String) {
        val builder = AlertDialog.Builder(this)

        builder.setMessage("This seems to be a new account. Would you like for us to create an account for you?")
        builder.setCancelable(true)
        builder.setPositiveButton("Yes") { dialog, id ->
            // Similar to the ContentValues when we were discussing SQLite, we can use a
            // HashMap to store a key value pair (String, Object pair). This HashMap will be
            // sent to the DB and the strings will form the fields, while the objects will
            // form the values.
            val data: MutableMap<String, Any> = HashMap()
            // We are only storing the username in the User Collection
            data[MyFirestoreReferences.USERNAME_FIELD] = username

            // add() is like insert(); with the User Collection, we add the HashMap values.
            // We don't include an ID because straight up adding a value without an ID auto
            // generates the ID. If you want to set the ID, you'd want to use set().
            // Additionally, we add an OnSuccessListener and OnFailureListener. They don't
            // do anything important right now, but you can see that we can retrieve the ID
            // in case you'd like to utilize it client side.
            usersRef
                .add(data)
                .addOnSuccessListener { documentReference ->
                    Log.d(TAG, "DocumentSnapshot written with ID: " + documentReference.id)
                    // If the add was successful, we'd want to move to the
                    // ChatRoomActivity
                    moveToChatRoomActivity(username)
                }
                .addOnFailureListener { e -> Log.w(TAG, "Error adding document", e) }
        }
        builder.setNegativeButton("No") { dialog, id -> dialog.cancel() }

        val alert = builder.create()
        alert.show()
    }

    /*
     * This method was created to reduce the lines of code needed since this is called twice -- one
     * if the username was found and two if the user agrees to encode the username into the DB.
     * */
    private fun moveToChatRoomActivity(username: String) {
        val i = Intent(this@LoginActivity, ChatRoomActivity::class.java)

        // We send the username instead of querying it in the ChatRoomActivity to reduce the number
        // of network requests our app will make.
        i.putExtra(IntentKeys.USERNAME.name, username)
        startActivity(i)
    }
}