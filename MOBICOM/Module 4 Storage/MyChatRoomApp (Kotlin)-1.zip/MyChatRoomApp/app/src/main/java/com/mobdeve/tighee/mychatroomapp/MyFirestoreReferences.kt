package com.mobdeve.tighee.mychatroomapp

object MyFirestoreReferences {
    const val USERS_COLLECTION = "Users"
    const val MESSAGE_COLLECTION = "Message"
    const val USERNAME_FIELD = "username"
    const val MESSAGE_FIELD = "message"
    const val TIMESTAMP_FIELD = "timestamp"
}