package com.mobdeve.tighee.mychatroomapp

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.firebase.ui.firestore.FirestoreRecyclerOptions
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.mobdeve.tighee.mychatroomapp.databinding.ActivityMainBinding

class ChatRoomActivity : AppCompatActivity() {
    companion object {
        private const val TAG = "ChatRoomActivity"
    }

    // Replacement of the base adapter view
    private lateinit var myFirestoreRecyclerAdapter: MyFirestoreRecyclerAdapter

    // DB reference
    private lateinit var dbRef: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val viewBinding : ActivityMainBinding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        // Get username sent from the LoginActivity and display it with the welcoming text
        val username = intent.getStringExtra(IntentKeys.USERNAME.name)!!
        viewBinding.welcomeTv.text = "Welcome, $username!"

        // Get the messages from the Message Collection
        dbRef = Firebase.firestore
        val query = dbRef
            .collection(MyFirestoreReferences.MESSAGE_COLLECTION)
            .orderBy(MyFirestoreReferences.TIMESTAMP_FIELD)

        /*
         * IMPLEMENTING THE RECYCLERVIEW WITH A TWIST
         * In the next part here, we're going to set up the adapter for the RecyclerView; however,
         * this isn't like how we'd normally set up an adapter we've done before. For this, we want
         * our RecyclerView to be updated whenever anything in our DB changes; hence, we'll use the
         * FirestoreRecyclerAdapter<OurModel, OurViewHolder>. This integrates with Firebase
         * seamlessly.
         * see: https://github.com/firebase/FirebaseUI-Android/blob/master/firestore/README.md#using-the-firestorerecycleradapter
         * */

        // We first define options for our FirestoreRecyclerAdapter. The documentation for this is
        // quite poor, but all we can assess is that (1) the adapter is going to be able to build a
        // <Message and (2) utilize the query for Messages we defined awhile ago.
        val options = FirestoreRecyclerOptions.Builder<Message>()
            .setQuery(query, Message::class.java)
            .build()

        // We pass the options and the username into our custom FirestoreRecyclerAdapter class. We
        // could opt to just define the class in this class, but I like keeping things separate;
        // hence, why I'm passing in the username so the adapter knows how to adjust the left or
        // right align of the message.
        myFirestoreRecyclerAdapter = MyFirestoreRecyclerAdapter(options, username)

        // After which, we simply assign the adapter to our RecyclerView.
        viewBinding.recyclerView.adapter = myFirestoreRecyclerAdapter

        // The layout for the RecyclerView is a little different din, but nothing new. Here, we
        // want our messages to start from the bottom; hence, the stack from end being set to true.
        val linearLayoutManager = LinearLayoutManager(this)
        linearLayoutManager.stackFromEnd = true
        linearLayoutManager.isSmoothScrollbarEnabled = true
        viewBinding.recyclerView.layoutManager = linearLayoutManager

        /*
         * The send button logic revolves around pushing a message instance to the DB. With this,
         * we use the username, message, and serverTimestamp field. We don't pass the ID because am
         * add() method call without setting the ID auto generates the ID.
         * */
        viewBinding.sendBtn.setOnClickListener(View.OnClickListener {
            val message = viewBinding.messageEtv.text.toString()

            // Ready the values of the message
            val data: MutableMap<String, Any?> = HashMap()
            data[MyFirestoreReferences.USERNAME_FIELD] = username
            data[MyFirestoreReferences.MESSAGE_FIELD] = message
            data[MyFirestoreReferences.TIMESTAMP_FIELD] = FieldValue.serverTimestamp()

            // Send the data off to the Message collection
            dbRef.collection(MyFirestoreReferences.MESSAGE_COLLECTION).add(data)
                .addOnSuccessListener { documentReference ->
                    Log.d(TAG, "DocumentSnapshot written with ID: " + documentReference.id)
                    // "Reset" the message in the EditText
                    viewBinding.messageEtv.setText("")
                }
                .addOnFailureListener { e -> Log.w(TAG, "Error adding document", e) }
        })
    }

    override fun onStart() {
        super.onStart()

        // When our app is open, we need to have the adapter listening for any changes in the data.
        // To do so, we'd want to turn on the listening using the appropriate method in the onStart
        // or onResume (basically before the start but within the loop)
        this.myFirestoreRecyclerAdapter.startListening()
    }

    override fun onStop() {
        super.onStop()

        // We want to eventually stop the listening when we're about to exit an app as we don't need
        // something listening all the time in the background.
        this.myFirestoreRecyclerAdapter.stopListening()
    }
}