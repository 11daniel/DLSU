package com.mobdeve.tighee.farminggameapp;

public class Grapes extends Product {
    public Grapes() {
        super("Grapes" ,20, R.drawable.grapes, 30, 40);
    }
}
