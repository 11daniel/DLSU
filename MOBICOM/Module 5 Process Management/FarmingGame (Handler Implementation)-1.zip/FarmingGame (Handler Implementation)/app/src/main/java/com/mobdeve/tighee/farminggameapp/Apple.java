package com.mobdeve.tighee.farminggameapp;

public class Apple extends Product {
    public Apple() {
        super("Apple", 8, R.drawable.shiny_apple, 15, 20);
    }
}
