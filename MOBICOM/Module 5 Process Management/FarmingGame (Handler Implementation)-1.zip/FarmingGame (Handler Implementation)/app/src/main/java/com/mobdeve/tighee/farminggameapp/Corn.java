package com.mobdeve.tighee.farminggameapp;

public class Corn extends Product {
    public Corn() {
        super("Corn", 4, R.drawable.corn, 10, 13);
    }
}
