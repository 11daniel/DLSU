package com.mobdeve.mynotesapplication

/*
 *      NOTE: You are not allowed to modify anything in this file.
 */
class NoteModel(var title : String, var body : String)