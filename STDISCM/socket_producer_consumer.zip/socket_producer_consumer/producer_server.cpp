#include <iostream>
#include <thread>
#include <queue>
#include <mutex>
#include <string>
#include <chrono>
#include <arpa/inet.h>
#include <unistd.h>

/**
 * Producer Server:
 * - Generates random numbers
 * - Sends first number in queue to requesting client
 * 
 * g++ -std=c++20 producer_server.cpp -o producer
 */

const int PORT = 5001;

std::deque<int> num_queue;
std::mutex queue_mutex;

// Continuously puts random numbers into the queue
void generate_numbers() {
    srand(time(nullptr));

    while (true) {
        int num = rand() % 100 + 1;
        {
            std::lock_guard<std::mutex> lock(queue_mutex);
            num_queue.push_back(num);
        }

        std::cout << "Producer: Generated " << num << std::endl;
        std::this_thread::sleep_for(std::chrono::milliseconds(500));
    }
}

// Handles a single client connection
void handle_client(int sock, sockaddr_in addr) {
    char ip[INET_ADDRSTRLEN];
    inet_ntop(AF_INET, &addr.sin_addr, ip, sizeof(ip));
    int port = ntohs(addr.sin_port);

    std::cout << "[Notification] " << ip << ":" << port << " connected" << std::endl;

    char buffer[1024];

    while(true) {
        // Read bytes from socket buffer
        // 1024 is max bytes that will be read
        memset(buffer, 0, sizeof(buffer));
        int read_len = read(sock, buffer, 1024);
        if (read_len <= 0) break;  // Client disconnected

        std::string request = buffer;
        if (request == "GET") {
            std::string reply;

            {
                std::lock_guard<std::mutex> lock(queue_mutex);
                if (!num_queue.empty()) {
                    reply = std::to_string(num_queue.front());
                    num_queue.pop_front();
                } else {
                    reply = "NONE";
                }
            }

            // Send reply via the socket
            send(sock, reply.c_str(), reply.size(), 0);
        }
    }

    std::cout << "[Notification] " << ip << ":" << port << " disconnected" << std::endl;
    close(sock);
}

// Server thread
void start_server() {
    sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;  // 0.0.0.0
    addr.sin_port = htons(PORT);

    // Create a IPv4 TCP socket, then bind to network address
    int server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (bind(server_fd, (sockaddr*)&addr, sizeof(addr)) < 0) {
        std::cerr << "[Error] Bind failed" << std::endl;
        return;
    }

    // Listen for clients
    if (listen(server_fd, 10) < 0) {
        std::cerr << "[Error] Listen failed" << std::endl;
        return;
    }

    std::cout << "[Notification] Listening on port " << PORT << std::endl;

    // Accept each client connection and handle it with a dedicated thread
    while(true) {
        sockaddr_in client_addr;
        socklen_t client_len = sizeof(client_addr);
        
        int client_fd = accept(server_fd, (sockaddr*)&client_addr, &client_len);
        if (client_fd < 0) {
            std::cerr << "[Error] Failed to accept client" << std::endl;
            continue;
        }

        std::thread client_thread(handle_client, client_fd, client_addr);
        client_thread.detach();
    }
}

int main() {
    // Start server and handle connections asynchronously
    // so other tasks are not blocked
    std::thread server_thread(start_server);
    server_thread.detach();

    generate_numbers();
}
