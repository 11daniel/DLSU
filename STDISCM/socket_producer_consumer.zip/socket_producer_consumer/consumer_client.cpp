#include <iostream>
#include <thread>
#include <chrono>
#include <cstring>
#include <arpa/inet.h>
#include <unistd.h>

/**
 * Consumer Client:
 * - Connect to producer server
 * - Retrieve the first number in the queue
 * 
 * g++ -std=c++20 consumer_client.cpp -o consumer
 */

const char* PRODUCER_IP = "192.168.68.106";  // Replace with IP address of server machine
const int PORT = 5001;

// Continuously retrieve number from producer
void retrieve_number(int id) {
    sockaddr_in server_addr;
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    inet_pton(AF_INET, PRODUCER_IP, &server_addr.sin_addr);

    // Create a IPv4 TCP socket and connect to server address
    int client_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (connect(client_fd, (sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        std::cerr << "[Error] Consumer " << id << " failed to connect" << std::endl;
        close(client_fd);
        return;
    }

    std::cout << "[Notification] Consumer " << id << " connected to " << PRODUCER_IP << ":" << PORT << std::endl;

    char buffer[1024];

    while(true) {
        // Send request via the socket
        std::string request = "GET";
        send(client_fd, request.c_str(), request.size(), 0);

        // Read bytes from socket buffer
        memset(buffer, 0, sizeof(buffer));
        int read_len = recv(client_fd, buffer, sizeof(buffer) - 1, 0);
        if (read_len <= 0) {  // Server disconnected
            std::cout << "[Notification] Consumer " << id << " disconnected" << std::endl;
            break;
        }

        std::string data = buffer;
        if (data != "NONE") {
            std::cout << "Consumer " << id << ": Retrieved " << data << std::endl;
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(500));
    }

    close(client_fd);
}

int main() {
    // Create two consumer threads
    std::thread t1(retrieve_number, 1);
    std::thread t2(retrieve_number, 2);
    
    t1.join();
    t2.join();

    return 0;
}