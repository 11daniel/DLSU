file(REMOVE_RECURSE
  "CMakeFiles/ocr_server.dir/ocr_server.cpp.o"
  "CMakeFiles/ocr_server.dir/ocr_server.cpp.o.d"
  "ocr_server"
  "ocr_server.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/ocr_server.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
