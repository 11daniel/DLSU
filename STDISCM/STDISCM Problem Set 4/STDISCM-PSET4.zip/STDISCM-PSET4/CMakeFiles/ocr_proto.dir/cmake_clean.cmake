file(REMOVE_RECURSE
  "CMakeFiles/ocr_proto.dir/ocr.grpc.pb.cc.o"
  "CMakeFiles/ocr_proto.dir/ocr.grpc.pb.cc.o.d"
  "CMakeFiles/ocr_proto.dir/ocr.pb.cc.o"
  "CMakeFiles/ocr_proto.dir/ocr.pb.cc.o.d"
  "libocr_proto.a"
  "libocr_proto.pdb"
  "ocr.grpc.pb.cc"
  "ocr.grpc.pb.h"
  "ocr.pb.cc"
  "ocr.pb.h"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/ocr_proto.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
