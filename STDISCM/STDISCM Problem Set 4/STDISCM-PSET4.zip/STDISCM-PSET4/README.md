# Distributed OCR Server

A high-performance, multithreaded OCR server implementation using C++, gRPC, and Tesseract.

## Features

### Multithreading
- **Thread Pool Architecture**: Dynamically manages worker threads for concurrent OCR processing
- **Task Queue**: Thread-safe queue using mutex and condition variables
- **Worker Thread Management**: Auto-scales based on hardware concurrency
- **Per-Thread OCR Engines**: Each thread maintains its own Tesseract instance to avoid contention

### Synchronization
- **Mutex Protection**: Ensures thread-safe access to shared resources (task queue, OCR engines)
- **Condition Variables**: Efficient thread wake-up mechanism for task distribution
- **Atomic Operations**: Thread counters for monitoring active threads and pending requests
- **Promise/Future Pattern**: Asynchronous result delivery from worker threads to gRPC handlers

### Interprocess Communication (IPC)
- **gRPC Framework**: High-performance RPC for client-server communication
- **Protocol Buffers**: Efficient binary serialization for image data transfer
- **Streaming Support**: Can handle large image files (up to 50MB default)
- **Bi-directional Communication**: Request-response pattern with error handling

### Fault Tolerance
- **Exception Handling**: Comprehensive try-catch blocks at all critical points
- **Graceful Degradation**: Server continues operating even if individual requests fail
- **Connection Monitoring**: Health check endpoint for client connection verification
- **Resource Cleanup**: Proper cleanup of temporary files and memory
- **Thread Safety**: All shared resources protected against race conditions

## Architecture

```
┌─────────────────────────────────────────────────────┐
│                   OCR Server                        │
├─────────────────────────────────────────────────────┤
│  gRPC Service Layer                                 │
│  ├─ ProcessImage()  - Main OCR endpoint             │
│  └─ HealthCheck()   - Connection monitoring         │
├─────────────────────────────────────────────────────┤
│  Thread Pool Manager                                │
│  ├─ Task Queue (mutex protected)                    │
│  ├─ Worker Threads (N = hardware_concurrency)       │
│  └─ Condition Variable (task notification)          │
├─────────────────────────────────────────────────────┤
│  OCR Processing Layer                               │
│  ├─ Tesseract Engines (one per thread)              │
│  ├─ Leptonica Image Loading                         │
│  └─ Text Extraction Pipeline                        │
└─────────────────────────────────────────────────────┘
```

## Request Flow

1. **Client Request**: gRPC client sends ImageRequest with image data
2. **Service Handler**: OCRServiceImpl receives request
3. **Task Enqueue**: Request added to thread-safe task queue
4. **Thread Wake-up**: Condition variable notifies idle worker thread
5. **OCR Processing**: Worker thread:
   - Writes image to temporary file
   - Loads image with Leptonica
   - Performs OCR with Tesseract
   - Extracts text
   - Cleans up resources
6. **Result Delivery**: Promise/future mechanism returns result
7. **gRPC Response**: OCRResponse sent back to client

## Key Components

### OCRThreadPool Class
Manages worker threads and task distribution:
- `enqueue()`: Adds OCR task to queue, returns future
- `worker_thread()`: Main loop for processing tasks
- `process_ocr()`: Performs actual OCR operation

### OCRServiceImpl Class
gRPC service implementation:
- `ProcessImage()`: Handles OCR requests
- `HealthCheck()`: Provides server status

### Synchronization Primitives
- `std::mutex queue_mutex`: Protects task queue
- `std::condition_variable cv`: Signals task availability
- `std::atomic<int>`: Thread-safe counters
- `std::promise/future`: Async result passing

## Protocol Buffers Definition

### ImageRequest
- `image_id`: Unique identifier for tracking
- `image_data`: Raw image bytes
- `client_id`: Client identification

### OCRResponse
- `image_id`: Corresponding request ID
- `extracted_text`: OCR result text
- `success`: Processing status
- `error_message`: Error details if failed

### HealthResponse
- `healthy`: Server operational status
- `active_threads`: Current processing threads
- `pending_requests`: Queued tasks

## Performance Characteristics

### Throughput
- Concurrent processing of multiple images
- No blocking between requests
- Scales with CPU cores

### Latency
- Immediate enqueuing (< 1ms)
- OCR processing: 100ms - 2s (depending on image complexity)
- Result delivery: < 10ms

### Resource Usage
- Memory: ~100MB base + ~50MB per active thread
- CPU: Scales linearly with thread count
- Disk: Temporary files (cleaned up automatically)

## Error Handling

### Network Errors
- Client disconnection: Request abandoned, resources cleaned
- Timeout: Configurable at gRPC level
- Invalid data: Returns error response

### Processing Errors
- Image loading failure: Error message returned
- OCR failure: Graceful handling, empty text returned
- File I/O errors: Logged and reported to client

### Thread Safety Errors
- All prevented through proper synchronization
- No race conditions in task queue
- No deadlocks in mutex acquisition

## Monitoring and Debugging

### Log Output
```
=== Received OCR Request ===
Image ID: img_001
Client ID: client_alpha
Image size: 245678 bytes
Total requests: 42

[Thread 3] Processing image: img_001
[Thread 3] Completed image: img_001
Request img_001 completed successfully
```

### Health Monitoring
Use HealthCheck RPC to monitor:
- Server availability
- Active processing threads
- Pending request count

### Performance Metrics
- Total requests processed
- Average processing time per image
- Thread utilization rate

## Security Considerations

### Current Implementation (Development)
- Uses `InsecureServerCredentials` for testing
- No authentication/authorization
- No encryption

### Production Recommendations
- Implement TLS/SSL: `SslServerCredentials`
- Add authentication: JWT tokens or API keys
- Rate limiting per client
- Input validation for image data
- Sandbox OCR processing
- Resource quotas per client

## Scalability

### Horizontal Scaling
- Deploy multiple server instances
- Use load balancer (e.g., gRPC load balancing)
- Stateless design enables easy scaling

### Vertical Scaling
- Increase thread pool size
- Allocate more CPU cores
- Increase memory for larger images

## Future Enhancements

1. **Caching**: Cache OCR results for duplicate images
2. **Batch Processing**: Process multiple images in single request
3. **Priority Queue**: Prioritize certain clients/requests
4. **GPU Acceleration**: Use GPU for image preprocessing
5. **Distributed Queue**: Use RabbitMQ/Redis for task distribution
6. **Metrics**: Prometheus integration for monitoring
7. **Language Support**: Multi-language OCR configuration

## Dependencies

- **gRPC**: >= 1.45
- **Protocol Buffers**: >= 3.19
- **Tesseract**: >= 4.0
- **Leptonica**: >= 1.78
- **C++ Standard**: C++17

## License

Educational project for STDISCM Problem Set 4.