# OCR Server Build Instructions

## Prerequisites

### Ubuntu/Debian
```bash
sudo apt-get update
sudo apt-get install -y \
    build-essential \
    cmake \
    pkg-config \
    libgrpc++-dev \
    libprotobuf-dev \
    protobuf-compiler-grpc \
    libtesseract-dev \
    libleptonica-dev \
    tesseract-ocr-eng
```

### macOS
```bash
brew install grpc protobuf tesseract leptonica cmake pkg-config
```

### CentOS/RHEL
```bash
sudo yum install -y epel-release
sudo yum install -y \
    gcc-c++ \
    cmake \
    pkgconfig \
    grpc-devel \
    protobuf-devel \
    tesseract-devel \
    leptonica-devel
```

## Project Structure
```
ocr-server/
├── CMakeLists.txt
├── ocr.proto
├── ocr_server.cpp
├── BUILD_INSTRUCTIONS.md
└── README.md
```

## Build Steps

1. **Create build directory**
```bash
mkdir build
cd build
```

2. **Configure with CMake**
```bash
cmake ..
```

3. **Build the server**
```bash
make -j$(nproc)
```

4. **Run the server**
```bash
./ocr_server [address] [num_threads]
```

**Example:**
```bash
# Run on default port with auto-detected threads
./ocr_server

# Run on custom port with 8 threads
./ocr_server 0.0.0.0:8080 8

# Run on specific IP
./ocr_server 192.168.1.100:50051 4
```

## Configuration

### Port Configuration
- Default: `0.0.0.0:50051`
- Change via command line argument

### Thread Pool Size
- Default: Auto-detected (hardware concurrency)
- Change via command line argument

### Firewall Configuration
If running on a separate machine/VM, ensure the port is open:
```bash
# Ubuntu/Debian
sudo ufw allow 50051/tcp

# CentOS/RHEL
sudo firewall-cmd --add-port=50051/tcp --permanent
sudo firewall-cmd --reload
```

## Testing the Server

### Using grpcurl
```bash
# Install grpcurl
go install github.com/fullstorydev/grpcurl/cmd/grpcurl@latest

# Health check
grpcurl -plaintext -d '{"client_id": "test"}' \
    localhost:50051 ocr.OCRService/HealthCheck

# Test with image (base64 encoded)
grpcurl -plaintext -d '{
    "image_id": "test1",
    "image_data": "'$(base64 -w 0 test_image.png)'",
    "client_id": "test_client"
}' localhost:50051 ocr.OCRService/ProcessImage
```

## Troubleshooting

### Tesseract Data Files
If you get "Failed to load language 'eng'" error:
```bash
# Check tessdata location
tesseract --version

# Install English training data
sudo apt-get install tesseract-ocr-eng

# Or manually download
wget https://github.com/tesseract-ocr/tessdata/raw/main/eng.traineddata
sudo mv eng.traineddata /usr/share/tesseract-ocr/4.00/tessdata/
```

### gRPC Connection Issues
- Ensure the server IP/port is correct
- Check firewall settings
- Verify network connectivity: `telnet <server_ip> 50051`

### Memory Issues with Large Images
The server is configured for 50MB max message size. Adjust in code if needed:
```cpp
builder.SetMaxReceiveMessageSize(100 * 1024 * 1024); // 100MB
```

## Performance Tuning

### Thread Pool Size
- CPU-bound: Set to number of CPU cores
- I/O-bound: Set to 2x number of CPU cores
- Balanced: Use default (hardware_concurrency)

### Monitoring
The server logs:
- Request reception
- Thread assignment
- Processing completion
- Errors and exceptions

Check logs for performance bottlenecks.

## Production Deployment

### Using systemd (Linux)
Create `/etc/systemd/system/ocr-server.service`:
```ini
[Unit]
Description=Distributed OCR Server
After=network.target

[Service]
Type=simple
User=ocruser
WorkingDirectory=/opt/ocr-server
ExecStart=/opt/ocr-server/ocr_server 0.0.0.0:50051 8
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

Enable and start:
```bash
sudo systemctl enable ocr-server
sudo systemctl start ocr-server
sudo systemctl status ocr-server
```

### Docker Deployment
```dockerfile
FROM ubuntu:22.04

RUN apt-get update && apt-get install -y \
    libgrpc++1.45 \
    libtesseract4 \
    libleptonica-dev \
    tesseract-ocr-eng \
    && rm -rf /var/lib/apt/lists/*

COPY build/ocr_server /usr/local/bin/
EXPOSE 50051

CMD ["ocr_server", "0.0.0.0:50051"]
```

Build and run:
```bash
docker build -t ocr-server .
docker run -p 50051:50051 ocr-server
```