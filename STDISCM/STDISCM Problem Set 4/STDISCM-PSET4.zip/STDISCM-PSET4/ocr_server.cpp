#include <iostream>
#include <memory>
#include <string>
#include <thread>
#include <queue>
#include <mutex>
#include <condition_variable>
#include <atomic>
#include <vector>
#include <fstream>
#include <future>

#include <grpcpp/grpcpp.h>
#include <tesseract/baseapi.h>
#include <leptonica/allheaders.h>

#include "ocr.grpc.pb.h" //still testing

using grpc::Server;
using grpc::ServerBuilder;
using grpc::ServerContext;
using grpc::Status;
using ocr::OCRService;
using ocr::ImageRequest;
using ocr::OCRResponse;
using ocr::HealthRequest;
using ocr::HealthResponse;

// Thread pool for processing OCR requests
class OCRThreadPool {
private:
    struct Task {
        std::string image_id;
        std::string image_data;
        std::promise<OCRResponse> promise;
    };

    std::vector<std::thread> workers;
    std::queue<Task> tasks;
    std::mutex queue_mutex;
    std::condition_variable cv;
    std::atomic<bool> stop;
    std::atomic<int> active_threads;
    std::atomic<int> pending_requests;
    
    // Tesseract API instances (one per thread)
    std::vector<std::unique_ptr<tesseract::TessBaseAPI>> ocr_engines;
    std::mutex engines_mutex;

public:
    OCRThreadPool(size_t num_threads = std::thread::hardware_concurrency()) 
        : stop(false), active_threads(0), pending_requests(0) {
        
        // Initialize Tesseract engines
        for (size_t i = 0; i < num_threads; ++i) {
            auto engine = std::make_unique<tesseract::TessBaseAPI>();
            if (engine->Init(nullptr, "eng")) {
                std::cerr << "Could not initialize tesseract." << std::endl;
                continue;
            }
            ocr_engines.push_back(std::move(engine));
        }

        // Create worker threads
        for (size_t i = 0; i < num_threads; ++i) {
            workers.emplace_back([this, i] { this->worker_thread(i); });
        }
        
        std::cout << "OCR Thread Pool initialized with " << num_threads << " threads" << std::endl;
    }

    ~OCRThreadPool() {
        stop = true;
        cv.notify_all();
        
        for (auto& worker : workers) {
            if (worker.joinable()) {
                worker.join();
            }
        }
        
        // Clean up Tesseract engines
        for (auto& engine : ocr_engines) {
            if (engine) {
                engine->End();
            }
        }
    }

    std::future<OCRResponse> enqueue(const std::string& image_id, const std::string& image_data) {
        Task task;
        task.image_id = image_id;
        task.image_data = image_data;
        auto future = task.promise.get_future();

        {
            std::unique_lock<std::mutex> lock(queue_mutex);
            if (stop) {
                throw std::runtime_error("ThreadPool is stopped");
            }
            tasks.push(std::move(task));
            pending_requests++;
        }
        
        cv.notify_one();
        return future;
    }

    int get_active_threads() const {
        return active_threads.load();
    }

    int get_pending_requests() const {
        return pending_requests.load();
    }

private:
    void worker_thread(size_t thread_id) {
        std::cout << "Worker thread " << thread_id << " started" << std::endl;
        
        while (!stop) {
            Task task;
            
            {
                std::unique_lock<std::mutex> lock(queue_mutex);
                cv.wait(lock, [this] { return stop || !tasks.empty(); });
                
                if (stop && tasks.empty()) {
                    break;
                }
                
                if (tasks.empty()) {
                    continue;
                }
                
                task = std::move(tasks.front());
                tasks.pop();
                pending_requests--;
            }
            
            // Process the OCR task
            active_threads++;
            OCRResponse response = process_ocr(task.image_id, task.image_data, thread_id);
            active_threads--;
            
            task.promise.set_value(response);
        }
        
        std::cout << "Worker thread " << thread_id << " stopped" << std::endl;
    }

    OCRResponse process_ocr(const std::string& image_id, const std::string& image_data, size_t thread_id) {
        OCRResponse response;
        response.set_image_id(image_id);
        
        try {
            std::cout << "[Thread " << thread_id << "] Processing image: " << image_id << std::endl;
            
            // Write image data to temporary file
            std::string temp_filename = "/tmp/ocr_" + image_id + "_" + std::to_string(thread_id) + ".png";
            std::ofstream outfile(temp_filename, std::ios::binary);
            outfile.write(image_data.data(), image_data.size());
            outfile.close();
            
            // Load image using Leptonica
            Pix* image = pixRead(temp_filename.c_str());
            if (image == nullptr) {
                throw std::runtime_error("Failed to load image");
            }
            
            // Get Tesseract engine for this thread
            tesseract::TessBaseAPI* ocr_engine = nullptr;
            {
                std::lock_guard<std::mutex> lock(engines_mutex);
                if (thread_id < ocr_engines.size() && ocr_engines[thread_id]) {
                    ocr_engine = ocr_engines[thread_id].get();
                }
            }
            
            if (!ocr_engine) {
                pixDestroy(&image);
                throw std::runtime_error("OCR engine not available");
            }
            
            // Perform OCR
            ocr_engine->SetImage(image);
            char* text = ocr_engine->GetUTF8Text();
            
            if (text != nullptr) {
                response.set_extracted_text(text);
                response.set_success(true);
                delete[] text;
            } else {
                response.set_extracted_text("");
                response.set_success(true);
            }
            
            // Cleanup
            pixDestroy(&image);
            std::remove(temp_filename.c_str());
            
            std::cout << "[Thread " << thread_id << "] Completed image: " << image_id << std::endl;
            
        } catch (const std::exception& e) {
            std::cerr << "[Thread " << thread_id << "] Error processing image " 
                      << image_id << ": " << e.what() << std::endl;
            response.set_success(false);
            response.set_error_message(e.what());
        }
        
        return response;
    }
};

// gRPC Service Implementation
class OCRServiceImpl final : public OCRService::Service {
private:
    std::unique_ptr<OCRThreadPool> thread_pool;
    std::mutex service_mutex;
    std::atomic<int> total_requests;

public:
    OCRServiceImpl(size_t num_threads = std::thread::hardware_concurrency()) 
        : total_requests(0) {
        thread_pool = std::make_unique<OCRThreadPool>(num_threads);
    }

    Status ProcessImage(ServerContext* context, 
                       const ImageRequest* request,
                       OCRResponse* response) override {
        
        total_requests++;
        std::cout << "\n=== Received OCR Request ===" << std::endl;
        std::cout << "Image ID: " << request->image_id() << std::endl;
        std::cout << "Client ID: " << request->client_id() << std::endl;
        std::cout << "Image size: " << request->image_data().size() << " bytes" << std::endl;
        std::cout << "Total requests: " << total_requests.load() << std::endl;
        
        try {
            // Enqueue the task and wait for result
            auto future = thread_pool->enqueue(
                request->image_id(), 
                request->image_data()
            );
            
            // Wait for the OCR processing to complete
            *response = future.get();
            
            std::cout << "Request " << request->image_id() << " completed successfully" << std::endl;
            return Status::OK;
            
        } catch (const std::exception& e) {
            std::cerr << "Error processing request: " << e.what() << std::endl;
            response->set_image_id(request->image_id());
            response->set_success(false);
            response->set_error_message(e.what());
            return Status(grpc::StatusCode::INTERNAL, e.what());
        }
    }

    Status HealthCheck(ServerContext* context,
                      const HealthRequest* request,
                      HealthResponse* response) override {
        response->set_healthy(true);
        response->set_active_threads(thread_pool->get_active_threads());
        response->set_pending_requests(thread_pool->get_pending_requests());
        
        std::cout << "Health check from client: " << request->client_id() << std::endl;
        return Status::OK;
    }
};

// Server runner
void RunServer(const std::string& server_address, size_t num_threads) {
    OCRServiceImpl service(num_threads);

    ServerBuilder builder;
    builder.AddListeningPort(server_address, grpc::InsecureServerCredentials());
    builder.RegisterService(&service);
    
    // Increase max message size for large images (50MB)
    builder.SetMaxReceiveMessageSize(50 * 1024 * 1024);
    builder.SetMaxSendMessageSize(50 * 1024 * 1024);

    std::unique_ptr<Server> server(builder.BuildAndStart());
    std::cout << "\n========================================" << std::endl;
    std::cout << "OCR Server listening on " << server_address << std::endl;
    std::cout << "Thread pool size: " << num_threads << std::endl;
    std::cout << "========================================\n" << std::endl;

    server->Wait();
}

int main(int argc, char** argv) {
    std::string server_address = "0.0.0.0:50051";
    size_t num_threads = std::thread::hardware_concurrency();
    
    // Parse command line arguments
    if (argc > 1) {
        server_address = argv[1];
    }
    if (argc > 2) {
        num_threads = std::stoi(argv[2]);
    }
    
    std::cout << "Starting Distributed OCR Server..." << std::endl;
    std::cout << "Hardware concurrency: " << std::thread::hardware_concurrency() << std::endl;
    
    try {
        RunServer(server_address, num_threads);
    } catch (const std::exception& e) {
        std::cerr << "Server error: " << e.what() << std::endl;
        return 1;
    }
    
    return 0;
}