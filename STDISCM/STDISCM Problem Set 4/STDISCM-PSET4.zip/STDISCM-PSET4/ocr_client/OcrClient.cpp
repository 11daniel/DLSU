#include "OcrClient.h"
#include <QFile>
#include <QFileInfo>
#include <QThread>
#include <fstream>
#include <iostream>

OcrClient::OcrClient(QObject *parent) : QObject(parent) {}

void OcrClient::connectToServer(const QString &address) {
  auto channel = grpc::CreateChannel(address.toStdString(),
                                     grpc::InsecureChannelCredentials());
  stub_ = ocr::OCRService::NewStub(channel);
  Q_EMIT connectionStatusChanged(true, "Connected to " + address);
}

void OcrClient::processImage(const QString &filePath) {
  if (!stub_) {
    Q_EMIT imageProcessed(filePath, "", false, "Not connected to server");
    return;
  }

  // Run in a separate thread to avoid blocking UI
  QThread *thread = QThread::create([this, filePath]() {
    ocr::ImageRequest request;
    request.set_image_id(QFileInfo(filePath).fileName().toStdString());
    request.set_client_id("qt_client");

    // Read file
    std::ifstream file(filePath.toStdString(), std::ios::binary);
    if (!file) {
      Q_EMIT imageProcessed(filePath, "", false, "Failed to open file");
      return;
    }
    std::string data((std::istreambuf_iterator<char>(file)),
                     std::istreambuf_iterator<char>());
    request.set_image_data(data);

    ocr::OCRResponse response;
    grpc::ClientContext context;

    grpc::Status status = stub_->ProcessImage(&context, request, &response);

    if (status.ok()) {
      Q_EMIT imageProcessed(
          filePath, QString::fromStdString(response.extracted_text()),
          response.success(), QString::fromStdString(response.error_message()));
    } else {
      Q_EMIT imageProcessed(filePath, "", false,
                            QString::fromStdString(status.error_message()));
    }
  });
  connect(thread, &QThread::finished, thread, &QThread::deleteLater);
  thread->start();
}
