#include "MainWindow.h"
#include <QFileDialog>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QLabel>
#include <QMessageBox>
#include <QStatusBar>
#include <QVBoxLayout>

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent) {
  client = new OcrClient(this);
  setupUi();

  connect(client, &OcrClient::imageProcessed, this,
          &MainWindow::onImageProcessed);
  connect(client, &OcrClient::connectionStatusChanged, this,
          [this](bool connected, QString msg) {
            statusBar()->showMessage(msg);
            uploadButton->setEnabled(connected);
            connectButton->setEnabled(!connected);
            if (connected) {
              connectButton->setText("Connected");
            }
          });
}

void MainWindow::setupUi() {
  QWidget *centralWidget = new QWidget(this);
  setCentralWidget(centralWidget);
  QVBoxLayout *mainLayout = new QVBoxLayout(centralWidget);

  // Connection Bar
  QHBoxLayout *connLayout = new QHBoxLayout();
  addressInput = new QLineEdit("localhost:50051");
  connectButton = new QPushButton("Connect");
  connLayout->addWidget(new QLabel("Server Address:"));
  connLayout->addWidget(addressInput);
  connLayout->addWidget(connectButton);
  mainLayout->addLayout(connLayout);

  // Controls
  QHBoxLayout *ctrlLayout = new QHBoxLayout();
  uploadButton = new QPushButton("Upload Images");
  uploadButton->setEnabled(false); // Disabled until connected
  progressBar = new QProgressBar();
  progressBar->setValue(0);
  ctrlLayout->addWidget(uploadButton);
  ctrlLayout->addWidget(progressBar);
  mainLayout->addLayout(ctrlLayout);

  // Results Area
  QScrollArea *scrollArea = new QScrollArea();
  scrollArea->setWidgetResizable(true);
  resultsContainer = new QWidget();
  resultsLayout = new QGridLayout(resultsContainer);
  resultsLayout->setAlignment(Qt::AlignTop);
  scrollArea->setWidget(resultsContainer);
  mainLayout->addWidget(scrollArea);

  connect(connectButton, &QPushButton::clicked, this,
          &MainWindow::onConnectClicked);
  connect(uploadButton, &QPushButton::clicked, this,
          &MainWindow::onUploadClicked);

  resize(800, 600);
  setWindowTitle("OCR Client");
}

void MainWindow::onConnectClicked() {
  client->connectToServer(addressInput->text());
}

void MainWindow::onUploadClicked() {
  QStringList fileNames = QFileDialog::getOpenFileNames(
      this, "Select Images", "", "Images (*.png *.jpg *.jpeg *.bmp)");
  if (fileNames.isEmpty())
    return;

  // Reset progress if starting a new batch (optional logic, keeping it simple)
  if (processedImages == totalImages) {
    processedImages = 0;
    totalImages = 0;
    progressBar->setValue(0);

    // Clear previous results? Maybe user wants to keep them.
    // Let's keep them but maybe scroll to bottom.
  }

  totalImages += fileNames.size();
  progressBar->setMaximum(totalImages);

  for (const QString &fileName : fileNames) {
    client->processImage(fileName);
  }
}

void MainWindow::onImageProcessed(QString imageId, QString text, bool success,
                                  QString error) {
  processedImages++;
  progressBar->setValue(processedImages);
  addResultWidget(imageId, text, success, error);
}

void MainWindow::addResultWidget(const QString &imageId, const QString &text,
                                 bool success, const QString &error) {
  QGroupBox *box = new QGroupBox(QFileInfo(imageId).fileName());
  QVBoxLayout *layout = new QVBoxLayout(box);

  // Image Preview (Thumbnail)
  QLabel *imageLabel = new QLabel();
  QPixmap pixmap(imageId);
  if (!pixmap.isNull()) {
    imageLabel->setPixmap(
        pixmap.scaled(200, 200, Qt::KeepAspectRatio, Qt::SmoothTransformation));
  } else {
    imageLabel->setText("Image not found");
  }
  imageLabel->setAlignment(Qt::AlignCenter);
  layout->addWidget(imageLabel);

  // Result Text
  if (success) {
    QLabel *textLabel = new QLabel(text);
    textLabel->setWordWrap(true);
    textLabel->setStyleSheet("font-weight: bold; font-size: 14px;");
    textLabel->setTextInteractionFlags(Qt::TextSelectableByMouse);
    layout->addWidget(textLabel);
  } else {
    QLabel *errorLabel = new QLabel("Error: " + error);
    errorLabel->setStyleSheet("color: red;");
    layout->addWidget(errorLabel);
  }

  // Add to grid (3 columns)
  int row = resultsLayout->count() / 3;
  int col = resultsLayout->count() % 3;
  resultsLayout->addWidget(box, row, col);
}
