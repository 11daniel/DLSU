#pragma once

#include "OcrClient.h"
#include <QGridLayout>
#include <QLineEdit>
#include <QMainWindow>
#include <QProgressBar>
#include <QPushButton>
#include <QScrollArea>

class MainWindow : public QMainWindow {
  Q_OBJECT

public:
  explicit MainWindow(QWidget *parent = nullptr);

private slots:
  void onConnectClicked();
  void onUploadClicked();
  void onImageProcessed(QString imageId, QString text, bool success,
                        QString error);

private:
  void setupUi();
  void addResultWidget(const QString &imageId, const QString &text,
                       bool success, const QString &error);

  OcrClient *client;

  QLineEdit *addressInput;
  QPushButton *connectButton;
  QPushButton *uploadButton;
  QProgressBar *progressBar;
  QWidget *resultsContainer;
  QGridLayout *resultsLayout;

  int totalImages = 0;
  int processedImages = 0;
};
