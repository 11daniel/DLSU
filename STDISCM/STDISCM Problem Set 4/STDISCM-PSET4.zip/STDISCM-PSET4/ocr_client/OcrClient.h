#pragma once

#include "ocr.grpc.pb.h"
#include <QObject>
#include <QString>
#include <grpcpp/grpcpp.h>
#include <memory>

class OcrClient : public QObject {
  Q_OBJECT

public:
  explicit OcrClient(QObject *parent = nullptr);
  void connectToServer(const QString &address);
  void processImage(const QString &filePath);

signals:
  void imageProcessed(QString imageId, QString text, bool success,
                      QString error);
  void connectionStatusChanged(bool connected, QString message);

private:
  std::unique_ptr<ocr::OCRService::Stub> stub_;
};
