public interface UserInterface {
    String getInput(String prompt);
    void showMessage(String message);
}
