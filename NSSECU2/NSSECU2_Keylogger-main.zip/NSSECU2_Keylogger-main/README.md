# Install pynput in a Virtual Environment
### Create a virtual environment:
     python3 -m venv ~/pynput-env

### Activate the environment:
     source ~/pynput-env/bin/activate
     
Your prompt will now show (pynput-env).

### Install pynput inside the virtual environment:
     pip install pynput

### Run your script with the virtual environment's Python:
     python main.py

### (Optional) When done, deactivate the virtual environment:
     deactivate

### Safely delete virtual environment
     rm -r ~/pynput-env


# Features/Keys Implemented:
- Key.enter
- Key.caps_lock
- Key.space
- Key.backspace
- Key.tab
- Key.esc
- Key.left
- Key.right
- Key.delete
- Key.num_lock
- Key.shift | Key.shift_r | Key.shift_l
- Key.ctrl | Key.ctrl_r | Key.ctrl_l
- Key.alt | Key.alt_l | Key.alt_r


# Combo Keys Implemented:
- Shift + Esc       [Exit Program]
- Ctrl + Alt + T    [Open CMD in Linux]