public class Student{
    // ATTRIBUTES
    private String lastName;
    private String firstName;
    private double projectGrade;
    private double midtermExam;
    private double finalExam;
    private double finalGrade;
    
    // empty Constructor
    public Student(){
        this.lastName = "No last";
        this.firstName = "No first";
        this.projectGrade = 0;
        this.midtermExam = 0;
        this.finalExam = 0;
        this.finalGrade = 0;
    }

    // non-empty Constructor
    public Student(String lastName, String firstName, double projectGrade, double midtermExam, double finalExam){
        // given all values, use the complete setter method
        setStudent(lastName, firstName, projectGrade, midtermExam, finalExam);
    }

    // OTHER METHODS....
    /* TAKE NOTE: Code is not complete but is a good start for Student class.
     * This is barely what I have used in class earlier
     * You can use this for your Java programming practice
     */

    // setter method for all attributes
    public void setStudent(String lastName, String firstName, double projectGrade, double midtermExam, double finalExam){
        this.lastName = lastName;
        this.firstName = firstName;
        this.projectGrade = projectGrade;
        this.midtermExam = midtermExam;
        this.finalExam = finalExam;
    }

    // getter method for attribute lastName
    public String getLastName(){
        return this.lastName;
    }

}