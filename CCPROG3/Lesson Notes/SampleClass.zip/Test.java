public class Test {
    public static void main (String[] args){
        // instantiation of a Student object
        Student student = new Student();
        // display an attribute of the instance
        System.out.println(student.getLastName());
    }
}
