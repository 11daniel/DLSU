import java.util.ArrayList;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EmployeeController {
	private EmployeeView employeeView;
	private EmployeeModel employeeModel;

	public EmployeeController(EmployeeView employeeView, EmployeeModel employeeModel) {
		this.employeeView = employeeView;
		this.employeeModel = employeeModel;

		this.employeeView.setAddBtnListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String id = employeeView.getIdTfText();
				String name = employeeView.getNameTfText();

				boolean result = employeeModel.addEmployee(id, name);

				if(result) {
					employeeView.setFeedbackLblText("Add success!");
					employeeView.clearTextFields();
				} else {
					employeeView.setFeedbackLblText("Add failed :(");
				}
			}
		});

		this.employeeView.setViewBtnListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String displayText = "";

				for(Employee employee : employeeModel.getEmployeeList()) {
					displayText += employee.getName() + " (id. " + employee.getId() + ")\n";
				}

				employeeView.setEmployeeListLblText(displayText);
			}
		});
	}


}