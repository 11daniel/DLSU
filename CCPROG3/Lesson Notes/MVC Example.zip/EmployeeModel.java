import java.util.ArrayList;

public class EmployeeModel {
	private ArrayList<Employee> employeeList;

	public EmployeeModel() {
		this.employeeList = new ArrayList<Employee>();
	}

	public boolean addEmployee(String id, String name) {
		boolean result = false;
		try {
			this.employeeList.add(new Employee(Integer.parseInt(id), name));
			result = true;
		}
		catch(Exception e) {
			// No error should be thrown but this mimicks a database
			// Will through an error however if id not a number
			System.out.println("Error: " + e);
		}

		return result;
	}

	public ArrayList<Employee> getEmployeeList() {
		return this.employeeList;
	}
}