import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.JPanel;

import java.awt.FlowLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EmployeeView {
	private JFrame mainFrame;
	private JLabel idLbl, nameLbl, feedbackLbl;
	private JTextField idTf, nameTf;
	private JButton addBtn, viewBtn;
	private JTextArea employeeListTextArea;

	public EmployeeView() {
		this.mainFrame = new JFrame("My Simple GUI");

		this.mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.mainFrame.setLayout(new FlowLayout(FlowLayout.CENTER));
		this.mainFrame.setSize(250, 400);

		this.idLbl = new JLabel("Enter id:      ");
		this.nameLbl = new JLabel("Enter name: ");
		this.feedbackLbl = new JLabel();
		this.feedbackLbl.setPreferredSize(new Dimension(220, 30));

		this.employeeListTextArea = new JTextArea(" ");
		this.employeeListTextArea.setPreferredSize(new Dimension(220, 170));
		this.employeeListTextArea.setEditable(false);

		this.idTf = new JTextField();
		this.idTf.setColumns(10);
		this.nameTf = new JTextField();
		this.nameTf.setColumns(10);

		this.addBtn = new JButton("Add");
		this.addBtn.setPreferredSize(new Dimension(220, 30));
		this.viewBtn = new JButton("View");
		this.viewBtn.setPreferredSize(new Dimension(220, 30));

		JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		panel.add(this.idLbl);
		panel.add(this.idTf);
		panel.setPreferredSize(new Dimension(220, 30));
		this.mainFrame.add(panel);

		panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		panel.add(this.nameLbl);
		panel.add(this.nameTf);
		panel.setPreferredSize(new Dimension(220, 30));
		this.mainFrame.add(panel);

		this.mainFrame.add(addBtn);
		this.mainFrame.add(feedbackLbl);
		this.mainFrame.add(viewBtn);
		this.mainFrame.add(employeeListTextArea);

		this.mainFrame.setVisible(true);
	}

	public void setAddBtnListener(ActionListener actionListener) {
		this.addBtn.addActionListener(actionListener);
	}

	public void setViewBtnListener(ActionListener actionListener) {
		this.viewBtn.addActionListener(actionListener);
	}

	public void setFeedbackLblText(String text) {
		this.feedbackLbl.setText(text);
	}

	public void setEmployeeListLblText(String text) {
		this.employeeListTextArea.setText(text);
	}

	public String getIdTfText() {
		return this.idTf.getText();
	}

	public String getNameTfText() {
		return this.nameTf.getText();
	}

	public void clearTextFields() {
		this.idTf.setText("");
		this.nameTf.setText("");
	}
}