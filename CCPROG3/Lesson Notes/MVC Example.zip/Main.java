public class Main {
	public static void main(String[] args) {
		EmployeeView employeeView = new EmployeeView();
		EmployeeModel employeeModel = new EmployeeModel();

		EmployeeController employeeController = new EmployeeController(employeeView, employeeModel);
	}
}