//Interface
public interface Sellable {
    public double computePrice();
}