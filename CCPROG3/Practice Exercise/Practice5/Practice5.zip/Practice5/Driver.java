public class Driver {

	public static void main(String args[]) {
		ClassroomTestScripts test = new ClassroomTestScripts();
		test.runTestScript();
	}
}